<?php
/**
 * These functions are used to load template parts (partials) or actions when used within action hooks,
 * and they probably should never be updated or modified.
 *
 * @package Once
 */

if ( ! function_exists( 'csco_singular_post_type_before' ) ) {
	/**
	 * Add Before Singular Hooks for specific post type.
	 */
	function csco_singular_post_type_before() {
		if ( 'post' === get_post_type() ) {
			do_action( 'csco_post_content_before' );
		}
		if ( 'page' === get_post_type() ) {
			do_action( 'csco_page_content_before' );
		}
	}
}

if ( ! function_exists( 'csco_singular_post_type_after' ) ) {
	/**
	 * Add After Singular Hooks for specific post type.
	 */
	function csco_singular_post_type_after() {
		if ( 'post' === get_post_type() ) {
			do_action( 'csco_post_content_after' );
		}
		if ( 'page' === get_post_type() ) {
			do_action( 'csco_page_content_after' );
		}
	}
}

if ( ! function_exists( 'csco_singular_post_type_start' ) ) {
	/**
	 * Add Start Singular Hooks for specific post type.
	 */
	function csco_singular_post_type_start() {
		if ( 'post' === get_post_type() ) {
			do_action( 'csco_post_content_start' );
		}
		if ( 'page' === get_post_type() ) {
			do_action( 'csco_page_content_start' );
		}
	}
}

if ( ! function_exists( 'csco_singular_post_type_end' ) ) {
	/**
	 * Add End Singular Hooks for specific post type.
	 */
	function csco_singular_post_type_end() {
		if ( 'post' === get_post_type() ) {
			do_action( 'csco_post_content_end' );
		}
		if ( 'page' === get_post_type() ) {
			do_action( 'csco_page_content_end' );
		}
	}
}

if ( ! function_exists( 'csco_offcanvas' ) ) {
	/**
	 * Off-canvas
	 */
	function csco_offcanvas() {
		get_template_part( 'template-parts/offcanvas' );
	}
}

if ( ! function_exists( 'csco_navbar_nav_menu' ) ) {
	/**
	 * Header Nav Menu
	 */
	function csco_navbar_nav_menu() {
		if ( ! get_theme_mod( 'header_navigation_menu', true ) ) {
			return;
		}

		if ( has_nav_menu( 'primary' ) ) {
			$submenu_scheme = csco_light_or_dark( get_theme_mod( 'color_navbar_submenu', '#FFFFFF' ), null, ' cs-navbar-nav-submenu-dark' );

			wp_nav_menu( array(
				'menu_class'      => sprintf( 'navbar-nav %s', $submenu_scheme ),
				'theme_location'  => 'primary',
				'container'       => '',
				'container_class' => '',
			) );
		}
	}
}

if ( ! function_exists( 'csco_header_subscription' ) ) {
	/**
	 * Header Subscription
	 */
	function csco_header_subscription() {
		if ( 'subscription' !== get_theme_mod( 'header_top_content', 'subscription' ) ) {
			return;
		}

		if ( shortcode_exists( 'powerkit_subscription_form' ) ) {
			$bg_scheme = csco_light_or_dark( get_theme_mod( 'color_large_header_bg', '#FAFAFA' ), 'navbar-subscribe-dark', 'navbar-subscribe-light' );

			$title = get_theme_mod( 'header_subscribe_title', '<span>' . esc_html__( 'Subscribe', 'once' ) . '</span> ' . esc_html__( 'for New Stories', 'once' ) );
			?>
			<div class="navbar-subscribe <?php echo esc_attr( $bg_scheme ); ?>">
				<?php echo do_shortcode( sprintf( '[powerkit_subscription_form display_name="false" privacy="false" title="%s"]', $title ) ); ?>
			</div>
			<?php
		}
	}
}

if ( ! function_exists( 'csco_header_additional_menu' ) ) {
	/**
	 * Header Additional Menu
	 */
	function csco_header_additional_menu() {
		if ( 'additional' !== get_theme_mod( 'header_top_content', 'subscription' ) ) {
			return;
		}

		if ( has_nav_menu( 'additional' ) ) {
			$submenu_scheme = csco_light_or_dark( get_theme_mod( 'color_navbar_submenu', '#FFFFFF' ), null, ' cs-navbar-nav-submenu-dark' );

			wp_nav_menu( array(
				'menu_class'      => sprintf( 'navbar-nav %s', $submenu_scheme ),
				'theme_location'  => 'additional',
				'container'       => '',
				'container_class' => '',
				'depth'           => 1,
			) );
		}
	}
}

if ( ! function_exists( 'csco_header_social_links' ) ) {
	/**
	 * Header Social Links
	 */
	function csco_header_social_links() {

		if ( ! get_theme_mod( 'header_social_links', false ) ) {
			return;
		}

		if ( ! csco_powerkit_module_enabled( 'social_links' ) ) {
			return;
		}

		// If the Layout is selected With top bar, then disable social links in the content area.
		if ( 'with-top-bar' === get_theme_mod( 'header_layout', 'compact' ) && 'csco_navbar_content_right' === current_filter() ) {
			return;
		}

		$scheme  = get_theme_mod( 'header_social_links_scheme', 'light' );
		$maximum = get_theme_mod( 'header_social_links_maximum', 3 );
		$counts  = get_theme_mod( 'header_social_links_counts', true );

		if ( 'csco_navbar_content_right' === current_filter() ) {
			$color_mod_name = 'color_navbar_bg';
		} else {
			$color_mod_name = 'color_large_header_bg';
		}

		$bg_scheme = csco_light_or_dark( get_theme_mod( $color_mod_name, '#FFFFFF' ), null, ' cs-bg-dark' );
		?>
		<div class="navbar-social-links <?php echo esc_attr( $bg_scheme ); ?>">
			<?php
				powerkit_social_links( false, false, $counts, 'nav', $scheme, 'mixed', $maximum );
			?>
		</div>
		<?php
	}
}

if ( ! function_exists( 'csco_header_follow' ) ) {
	/**
	 * Header Follow
	 */
	function csco_header_follow() {
		$button = get_theme_mod( 'header_follow_button_label', '<i class="cs-icon cs-icon-mail"></i>' . esc_html__( 'Subscribe', 'once' ) );
		$link   = get_theme_mod( 'header_follow_button_link', '' );

		if ( $button && $link ) {
			?>
			<div class="navbar-follow navbar-follow-button">
				<a class="button navbar-follow-btn" href="<?php echo esc_url( $link ); ?>" target="_blank">
					<?php echo wp_kses( $button, 'post' ); ?>
				</a>
			</div>
			<?php
		}
	}
}

if ( ! function_exists( 'csco_header_offcanvas_button' ) ) {
	/**
	 * Header Offcanvas Button
	 */
	function csco_header_offcanvas_button() {
		if ( csco_offcanvas_exists() ) {

			$class = sprintf( 'toggle-offcanvas-%s', get_theme_mod( 'header_offcanvas', true ) ? 'show' : 'hide' );

			if ( ! is_active_sidebar( 'sidebar-offcanvas' ) ) {
				$class = ' cs-d-lg-none';
			}
		?>
		<a class="navbar-toggle-offcanvas toggle-offcanvas <?php echo esc_attr( $class ); ?>">
			<span></span>
			<span></span>
			<span></span>
		</a>
		<?php
		}
	}
}

if ( ! function_exists( 'csco_header_logo' ) ) {
	/**
	 * Header Logo
	 */
	function csco_header_logo() {
		if ( 'csco_navbar_topbar_center' === current_filter() ) {
			$logo_id = get_theme_mod( 'large_logo' );
			$class   = 'large-title';
		} else {
			$logo_id = get_theme_mod( 'logo' );
			$class   = 'site-title';
		}
		?>
		<div class="navbar-brand">
			<?php

			if ( $logo_id ) {
				?>
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
					<?php csco_get_retina_image( $logo_id, array( 'alt' => get_bloginfo( 'name' ) ) ); ?>
				</a>
				<?php
			} else {
				?>
				<a class="<?php echo esc_attr( $class ); ?>" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a>
				<?php
			}

			if ( 'large' === get_theme_mod( 'header_layout', 'compact' ) && get_theme_mod( 'header_tagline' ) ) {
				?>
				<span class="tagline"><?php bloginfo( 'description' ); ?></span>
				<?php
			}
			?>
		</div>
		<?php
	}
}

if ( ! function_exists( 'csco_header_search_button' ) ) {
	/**
	 * Header Social Links
	 */
	function csco_header_search_button() {
		if ( ! get_theme_mod( 'header_search_button', true ) ) {
			return;
		}
		?>
		<a class="navbar-toggle-search toggle-search">
			<i class="cs-icon cs-icon-search"></i>
		</a>
		<?php
	}
}

if ( ! function_exists( 'csco_footer_logo' ) ) {
	/**
	 * Footer Logo
	 */
	function csco_footer_logo() {
		$logo_id = get_theme_mod( 'footer_logo' );
		if ( $logo_id ) {
			?>
			<span class="site-title footer-title" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
				<?php csco_get_retina_image( $logo_id, array( 'alt' => get_bloginfo( 'name' ) ) ); ?>
			</span>
			<?php
		} else {
			?>
			<div class="footer-title"><?php echo wp_kses_post( get_bloginfo( 'name' ) ); ?></div>
			<?php
		}
	}
}

if ( ! function_exists( 'csco_footer_social_links' ) ) {
	/**
	 * Footer Social Links
	 */
	function csco_footer_social_links() {

		if ( ! csco_powerkit_module_enabled( 'social_links' ) ) {
			return;
		}

		if ( get_theme_mod( 'footer_social_links', false ) ) {
			?>
				<div class="footer-social-links">
					<?php
					$scheme  = get_theme_mod( 'footer_social_links_scheme', 'light' );
					$maximum = get_theme_mod( 'footer_social_links_maximum', 4 );
					$counts  = get_theme_mod( 'footer_social_links_counts', true );

					powerkit_social_links( false, false, $counts, 'nav', $scheme, 'mixed', $maximum );
					?>
				</div>
		<?php
		}
	}
}

if ( ! function_exists( 'csco_footer_description' ) ) {
	/**
	 * Footer Description
	 */
	function csco_footer_description() {
		/* translators: %s: Author name. */
		$footer_text = get_theme_mod( 'footer_text', sprintf( esc_html__( 'Designed & Developed by %s', 'once' ), '<a href="' . esc_url( csco_get_theme_data( 'AuthorURI' ) ) . '">Code Supply Co.</a>' ) );
		if ( $footer_text ) {
			?>
			<div class="footer-copyright">
				<?php echo do_shortcode( $footer_text ); ?>
			</div>
			<?php
		}
	}
}

if ( ! function_exists( 'csco_footer_nav_menu' ) ) {
	/**
	 * Footer Nav Menu
	 */
	function csco_footer_nav_menu() {
		if ( has_nav_menu( 'footer' ) ) {
			?>
			<div class="footer-nav-menu">
				<?php
				wp_nav_menu(
					array(
						'theme_location'  => 'footer',
						'container_class' => 'navbar-footer',
						'menu_class'      => 'navbar-nav',
						'container'       => 'nav',
						'depth'           => 1,
					)
				);
				?>
			</div>
			<?php
		}
	}
}

if ( ! function_exists( 'csco_footer_subscription' ) ) {
	/**
	 * Footer Subscription
	 */
	function csco_footer_subscription() {
		if ( shortcode_exists( 'powerkit_subscription_form' ) ) {
			$title = get_theme_mod( 'footer_subscribe_title', esc_html__( 'Subscribe to', 'once' ) . "\n" . esc_html__( 'Our Updates', 'once' ) );
			$name  = get_theme_mod( 'footer_subscribe_name', false );
			?>
			<div class="footer-subscribe">
				<?php echo do_shortcode( sprintf( '[powerkit_subscription_form display_name="%s" title="%s"]', $name, nl2br( $title ) ) ); ?>
			</div>
			<?php
		}
	}
}

if ( ! function_exists( 'csco_single_share_button' ) ) {
	/**
	 * Post Share
	 */
	function csco_single_share_button() {
		if ( ! csco_powerkit_module_enabled( 'share_buttons' ) ) {
			return;
		}
		if ( is_single() ) {
			powerkit_share_buttons_location( 'after-post' );
		}
	}
}

if ( ! function_exists( 'csco_single_author' ) ) {
	/**
	 * Post Author
	 */
	function csco_single_author() {
		if ( ! is_singular( 'post' ) ) {
			return;
		}
		if ( ! csco_has_post_meta( 'author' ) ) {
			return;
		}
		get_template_part( 'template-parts/post-author' );
	}
}

if ( ! function_exists( 'csco_single_subscribe' ) ) {
	/**
	 * Post Subscribe
	 */
	function csco_single_subscribe() {
		if ( false === get_theme_mod( 'post_subscribe', false ) ) {
			return;
		}

		if ( csco_powerkit_module_enabled( 'opt_in_forms' ) ) {

			if ( ! is_singular( 'post' ) ) {
				return;
			}

			get_template_part( 'template-parts/post-subscribe' );
		}
	}
}

if ( ! function_exists( 'csco_single_prev_nex' ) ) {
	/**
	 * Post Prev Next
	 */
	function csco_single_prev_nex() {
		if ( ! is_singular( 'post' ) ) {
			return;
		}
		if ( 'disabled' === get_theme_mod( 'post_prev_next', 'along' ) ) {
			return;
		}
		get_template_part( 'template-parts/post-prev-next' );
	}
}

if ( ! function_exists( 'csco_comments' ) ) {
	/**
	 * Post Comments
	 */
	function csco_comments() {
		if ( post_password_required() ) {
			return;
		}

		if ( comments_open() || get_comments_number() ) {
			comments_template();
		}
	}
}

if ( ! function_exists( 'csco_site_search' ) ) {
	/**
	 * Site Search
	 */
	function csco_site_search() {
		get_template_part( 'template-parts/site-search' );
	}
}

if ( ! function_exists( 'csco_post_header' ) ) {
	/**
	 * Post Header
	 */
	function csco_post_header() {
		if ( ! is_singular() ) {
			return;
		}
		if ( 'none' === csco_get_page_header_type() ) {
			return;
		}
		get_template_part( 'template-parts/post-header' );
	}
}

if ( ! function_exists( 'csco_page_header' ) ) {
	/**
	 * Page Header
	 */
	function csco_page_header() {
		if ( ! ( is_archive() || is_search() || is_404() ) ) {
			return;
		}
		get_template_part( 'template-parts/page-header' );
	}
}

if ( ! function_exists( 'csco_breadcrumbs' ) ) {
	/**
	 * SEO Breadcrumbs
	 *
	 * @param bool $is_singular Display the breadcrumbs in full post.
	 * @param bool $echo        Output type.
	 */
	function csco_breadcrumbs( $is_singular = false, $echo = true ) {
		if ( is_front_page() || is_category() ) {
			return;
		}

		if ( ( is_singular( 'post' ) || is_singular( 'page' ) ) && ! $is_singular ) {
			return;
		}

		ob_start();

		if ( apply_filters( 'csco_breadcrumbs', true ) ) {
			if ( ! function_exists( 'yoast_breadcrumb' ) ) {
				return;
			}
			yoast_breadcrumb( '<div class="cs-breadcrumbs" id="breadcrumbs">', '</div>' );
		}

		// Check the number of levels in breadcrumbs.
		preg_match_all( '/<\/a>/', ob_get_contents(), $matches );

		if ( ! isset( $matches[0] ) || count( $matches[0] ) <= 1 ) {
			ob_end_clean();

			return;
		}

		if ( $echo ) {
			return ob_end_flush();
		}

		return ob_get_clean();
	}
}

if ( ! function_exists( 'csco_subcategories' ) ) {
	/**
	 * Subcategories
	 */
	function csco_subcategories() {

		if ( false === get_theme_mod( 'category_subcategories', false ) ) {
			return;
		}

		if ( ! is_category() ) {
			return;
		}

		$args = apply_filters( 'csco_subcategories_args', array(
			'parent' => get_query_var( 'cat' ),
		) );

		$categories = get_categories( $args );

		if ( $categories ) {
		?>
		<section class="subcategories">
			<?php $tag = apply_filters( 'csco_section_title_tag', 'h5' ); ?>
			<<?php echo esc_html( $tag ); ?> class="title-block"><?php esc_html_e( 'Subcategories', 'once' ); ?></<?php echo esc_html( $tag ); ?>>
			<ul class="cs-nav cs-nav-pills">
			<?php
			foreach ( $categories as $category ) {
				// Translators: category name.
				$title = sprintf( esc_html__( 'View all posts in %s', 'once' ), $category->name );
				$link  = get_category_link( $category->term_id )
				?>
					<li class="cs-nav-item">
						<a class="cs-nav-link" data-toggle="pill" href="<?php echo esc_url( $link ); ?>" title="<?php echo esc_attr( $title ); ?>">
							<?php echo esc_html( $category->name ); ?>
						</a>
					</li>
				<?php
			}
			?>
			</ul>
		</section>
		<?php
		}
	}
}

if ( ! function_exists( 'csco_homepage_sections' ) ) {
	/**
	 * Homepage Sections
	 */
	function csco_homepage_sections() {

		get_template_part( 'template-parts/home-sections' );
	}
}

if ( ! function_exists( 'csco_homepage_featured' ) ) {
	/**
	 * Homepage Featured Post
	 */
	function csco_homepage_featured() {

		if ( ! ( is_front_page() || is_home() ) ) {
			return;
		}

		$paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;

		if ( 1 !== $paged ) {
			return;
		}

		if ( is_front_page() && 'page' === get_option( 'show_on_front', 'posts' ) && 'home' === get_theme_mod( 'featured_location', 'front_page' ) ) {
			return;
		}

		if ( is_home() && 'page' === get_option( 'show_on_front', 'posts' ) && 'front_page' === get_theme_mod( 'featured_location', 'front_page' ) ) {
			return;
		}

		get_template_part( 'template-parts/home-featured' );
	}
}

if ( ! function_exists( 'csco_homepage_tiles' ) ) {
	/**
	 * Homepage Post Tiles
	 */
	function csco_homepage_tiles() {

		if ( ! ( is_front_page() || is_home() ) ) {
			return;
		}

		$paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;

		if ( 1 !== $paged ) {
			return;
		}

		if ( is_front_page() && 'page' === get_option( 'show_on_front', 'posts' ) && 'home' === get_theme_mod( 'tiles_location', 'front_page' ) ) {
			return;
		}

		if ( is_home() && 'page' === get_option( 'show_on_front', 'posts' ) && 'front_page' === get_theme_mod( 'tiles_location', 'front_page' ) ) {
			return;
		}

		get_template_part( 'template-parts/home-tiles' );
	}
}

if ( ! function_exists( 'csco_homepage_carousel' ) ) {
	/**
	 * Homepage Post Carousel
	 */
	function csco_homepage_carousel() {

		if ( ! ( is_front_page() || is_home() ) ) {
			return;
		}

		$paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;

		if ( 1 !== $paged ) {
			return;
		}

		if ( is_front_page() && 'page' === get_option( 'show_on_front', 'posts' ) && 'home' === get_theme_mod( 'carousel_location', 'front_page' ) ) {
			return;
		}

		if ( is_home() && 'page' === get_option( 'show_on_front', 'posts' ) && 'front_page' === get_theme_mod( 'carousel_location', 'front_page' ) ) {
			return;
		}

		get_template_part( 'template-parts/home-carousel' );
	}
}

if ( ! function_exists( 'csco_homepage_subscription' ) ) {
	/**
	 * Homepage Subscription
	 */
	function csco_homepage_subscription() {
		if ( ! csco_powerkit_module_enabled( 'opt_in_forms' ) ) {
			return;
		}

		if ( ! ( is_front_page() || is_home() ) ) {
			return;
		}

		$paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;

		if ( 1 !== $paged ) {
			return;
		}

		if ( is_front_page() && 'page' === get_option( 'show_on_front', 'posts' ) && 'home' === get_theme_mod( 'subscription_location', 'front_page' ) ) {
			return;
		}

		if ( is_home() && 'page' === get_option( 'show_on_front', 'posts' ) && 'front_page' === get_theme_mod( 'subscription_location', 'front_page' ) ) {
			return;
		}

		get_template_part( 'template-parts/home-subscription' );
	}
}

if ( ! function_exists( 'csco_related_posts' ) ) {
	/**
	 * Related Posts
	 */
	function csco_related_posts() {
		if ( ! is_singular( 'post' ) ) {
			return;
		}
		if ( false === get_theme_mod( 'related', true ) ) {
			return;
		}
		get_template_part( 'template-parts/related-posts' );
	}
}

if ( ! function_exists( 'csco_meet_team' ) ) {
	/**
	 * Meet Team
	 */
	function csco_meet_team() {
		if ( is_page_template( 'template-meet-team.php' ) ) {
			get_template_part( 'template-parts/meet-team' );
		}
	}
}
