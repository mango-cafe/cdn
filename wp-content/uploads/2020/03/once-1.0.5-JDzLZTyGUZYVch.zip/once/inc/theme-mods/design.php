<?php
/**
 * Design
 *
 * @package Once
 */

CSCO_Kirki::add_section(
	'design', array(
		'title'    => esc_html__( 'Design', 'once' ),
		'priority' => 20,
	)
);

/**
 * -------------------------------------------------------------------------
 * Colors
 * -------------------------------------------------------------------------
 */

CSCO_Kirki::add_section(
	'design_base', array(
		'title'    => esc_html__( 'design', 'once' ),
		'panel'    => 'design',
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'color',
		'settings' => 'color_primary',
		'label'    => esc_html__( 'Primary Color', 'once' ),
		'section'  => 'design',
		'priority' => 10,
		'default'  => '#c4a97c',
		'output'   => apply_filters( 'csco_color_primary', array(
			array(
				'element'  => 'a:hover, .entry-content a, .must-log-in a, blockquote:before, .post-meta a:hover, .post-meta a:focus, .post-meta .author a:hover, .post-meta .author a:focus, .cs-bg-dark .pk-social-links-scheme-bold:not(.pk-social-links-scheme-light-rounded) .pk-social-links-link .pk-social-links-icon, .subscribe-title, .entry-share .pk-share-buttons-scheme-default .pk-share-buttons-link:hover, .post-sidebar-shares .pk-share-buttons-scheme-default .pk-share-buttons-link:hover, .pk-share-buttons-after-post.pk-share-buttons-scheme-default .pk-share-buttons-link:hover',
				'property' => 'color',
			),
			array(
				'element'  => 'article .cs-overlay .post-categories a:hover, .cs-list-articles > li > a:hover:before, .wp-block-button .wp-block-button__link:not(.has-background), .pk-bg-primary, .pk-button-primary, .pk-pin-it:hover, .pk-badge-primary, h2.pk-heading-numbered:before, .cs-bg-dark .pk-social-links-scheme-light-rounded .pk-social-links-link:hover .pk-social-links-icon, .post-sidebar-shares .pk-share-buttons-link .pk-share-buttons-count, .pk-scroll-to-top:hover .cs-icon-arrow, .pk-widget-posts .pk-post-outer:hover .pk-current-number',
				'property' => 'background-color',
			),
		) ),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'color',
		'settings' => 'color_accent',
		'label'    => esc_html__( 'Accent Color', 'once' ),
		'section'  => 'design',
		'priority' => 10,
		'default'  => '#FAFAFA',
		'output'   => apply_filters( 'csco_color_accent', array(
			array(
				'element'  => '.site-search-wrap, .cs-featured-post-boxed .featured-post-inner, .widget_search .cs-input-group, .post-subscribe, .cs-bg-dark.post-prev-next-along, .widget .pk-subscribe-form-wrap, .pk-scroll-to-top .cs-icon-arrow, .pk-widget-posts .pk-current-number, .widget .pk-social-links-scheme-light-bg .pk-social-links-link, .widget .pk-social-links-scheme-light-rounded .pk-social-links-link .pk-social-links-icon',
				'property' => 'background-color',
			),
			array(
				'element'     => '.cs-bg-dark.post-prev-next-along .link-content:hover',
				'property'    => 'background-color',
				'media_query' => '@media (min-width: 1020px)',
			),
		) ),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'color',
		'settings' => 'color_button',
		'label'    => esc_html__( 'Button Color', 'once' ),
		'section'  => 'design',
		'priority' => 10,
		'default'  => '#000000',
		'output'   => apply_filters( 'csco_color_button', array(
			array(
				'element'  => 'button, input[type="button"], input[type="reset"], input[type="submit"], .button, .site .entry-content .pk-button-primary',
				'property' => 'color',
			),
		) ),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'color',
		'settings' => 'color_button_hover',
		'label'    => esc_html__( 'Button Hover Color', 'once' ),
		'section'  => 'design',
		'priority' => 10,
		'default'  => '#000000',
		'output'   => apply_filters( 'csco_color_button_hover', array(
			array(
				'element'  => 'button:hover, input[type="button"]:hover, input[type="reset"]:hover, input[type="submit"]:hover, .button:hover, .site .entry-content  .pk-button-primary:hover, .site .entry-content  .pk-button-primary:focus, .site .entry-content  .pk-button-primary:active',
				'property' => 'background-color',
			),
			array(
				'element'  => '.site button:before, .site .button:before, .site .load-more.loading:before',
				'property' => 'background-color',
			),
			array(
				'element'  => '.site button:hover, .site .button:hover',
				'property' => 'border-color',
			),
		) ),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'color',
		'settings'        => 'color_large_header_bg',
		'label'           => esc_html__( 'Header Background', 'once' ),
		'section'         => 'design',
		'default'         => '#FAFAFA',
		'priority'        => 10,
		'active_callback' => array(
			array(
				array(
					'setting'  => 'header_layout',
					'operator' => '==',
					'value'    => 'large',
				),
				array(
					'setting'  => 'header_layout',
					'operator' => '==',
					'value'    => 'with-top-bar',
				),
			),
		),
		'output'          => array(
			array(
				'element'  => '.header-large .navbar-topbar, .header-with-top-bar .navbar-topbar',
				'property' => 'background-color',
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'color',
		'settings' => 'color_navbar_bg',
		'label'    => esc_html__( 'Navigation Bar Background', 'once' ),
		'section'  => 'design',
		'default'  => '#FFFFFF',
		'priority' => 10,
		'output'   => array(
			array(
				'element'  => '.navbar-primary, .offcanvas-header',
				'property' => 'background-color',
			),
			array(
				'element'  => '.navbar-nav > .menu-item > a .pk-badge:after',
				'property' => 'border-color',
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'color',
		'settings' => 'color_navbar_submenu',
		'label'    => esc_html__( 'Navigation Submenu Background', 'once' ),
		'section'  => 'design',
		'default'  => '#FFFFFF',
		'priority' => 10,
		'output'   => array(
			array(
				'element'  => '.navbar-nav .menu-item .sub-menu, .navbar-nav .cs-mega-menu-has-category .sub-menu',
				'property' => 'background-color',
			),
			array(
				'element'  => '.navbar-nav > li.menu-item-has-children > .sub-menu:after',
				'property' => 'border-bottom-color',
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'color',
		'settings' => 'color_footer_bg',
		'label'    => esc_html__( 'Footer Background', 'once' ),
		'section'  => 'design',
		'default'  => '#FAFAFA',
		'priority' => 10,
		'output'   => array(
			array(
				'element'  => '.footer-info',
				'property' => 'background-color',
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'radio',
		'settings' => 'design_title_block',
		'label'    => esc_html__( 'Section Titles Design', 'once' ),
		'section'  => 'design',
		'default'  => 'right-border',
		'priority' => 10,
		'choices'  => array(
			'none'            => esc_html__( 'None', 'once' ),
			'right-border'    => esc_html__( 'Right border', 'once' ),
			'bottom-border'   => esc_html__( 'Bottom border', 'once' ),
			'bordered-center' => esc_html__( 'Bordered center aligned', 'once' ),
			'bordered-right'  => esc_html__( 'Bordered right aligned', 'once' ),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'radio',
		'settings' => 'design_category_separator',
		'label'    => esc_html__( 'Category & Title Separator', 'once' ),
		'section'  => 'design',
		'default'  => 'dash',
		'priority' => 10,
		'choices'  => array(
			'dash'    => esc_html__( 'Dash', 'once' ),
			'dot'     => esc_html__( 'Dot', 'once' ),
			'middle'  => esc_html__( 'Middle dot', 'once' ),
			'diamond' => esc_html__( 'Diamond', 'once' ),
			'square'  => esc_html__( 'Square', 'once' ),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'color',
		'settings' => 'color_category_separator',
		'label'    => esc_html__( 'Category & Title Separator Color', 'once' ),
		'section'  => 'design',
		'default'  => '#000000',
		'priority' => 10,
		'output'   => array(
			array(
				'element'  => '.meta-category-sep:after',
				'property' => 'color',
			),
			array(
				'element'  => '.meta-category-sep-dash:after, .meta-category-sep-middle:after, .meta-category-sep-diamond:after, .meta-category-sep-square:after, .meta-category-sep-brick:after',
				'property' => 'background-color',
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'radio',
		'settings' => 'design_title_effect',
		'label'    => esc_html__( 'Title Hover Effect', 'once' ),
		'section'  => 'design',
		'default'  => 'simple',
		'priority' => 10,
		'choices'  => array(
			'plain'     => esc_html__( 'Plain', 'once' ),
			'simple'    => esc_html__( 'Simple', 'once' ),
			'shadow'    => esc_html__( 'Shadow', 'once' ),
			'underline' => esc_html__( 'Underline', 'once' ),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'color',
		'settings'        => 'color_title_effect',
		'label'           => esc_html__( 'Title Hover Effect Color', 'once' ),
		'section'         => 'design',
		'default'         => '#c4a97c',
		'priority'        => 10,
		'choices'         => array(
			'alpha' => true,
		),
		'output'          => array(
			array(
				'element'  => '.entry-title-effect-simple a:hover .meta-category, .entry-title-effect-simple a:focus .meta-category, .entry-title-effect-simple .meta-category a:hover, .entry-title-effect-simple .meta-category a:focus',
				'property' => 'color',
			),
			array(
				'element'       => '.entry-title-effect-underline a .title-line, .entry-title-effect-shadow a .title-line',
				'property'      => 'background-image',
				'value_pattern' => 'linear-gradient(to right, $ 0%, $ 100%)',
			),
		),
		'active_callback' => array(
			array(
				'setting'  => 'design_title_effect',
				'operator' => '!=',
				'value'    => 'plain',
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'radio',
		'settings' => 'design_preview_effect',
		'label'    => esc_html__( 'Post Preview Hover Effect', 'once' ),
		'section'  => 'design',
		'default'  => 'none',
		'priority' => 10,
		'choices'  => array(
			'none'  => esc_html__( 'None', 'once' ),
			'scale' => esc_html__( 'Scale', 'once' ),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'              => 'dimension',
		'settings'          => 'design_border_radius',
		'label'             => esc_html__( 'Border Radius', 'once' ),
		'description'       => esc_html__( 'For example: 30px. If the input is empty, original value will be used.', 'once' ),
		'section'           => 'design',
		'default'           => '0',
		'priority'          => 10,
		'sanitize_callback' => 'esc_html',
		'output'            => apply_filters( 'csco_design_border_radius', array(
			array(
				'element'  => 'button, input[type="button"], input[type="reset"], input[type="submit"], .button, .pk-button, .cs-overlay .post-categories a, .site-search [type="search"], .subcategories .cs-nav-link, .post-header .pk-share-buttons-wrap .pk-share-buttons-link, .pk-dropcap-borders:first-letter, .pk-dropcap-bg-inverse:first-letter, .pk-dropcap-bg-light:first-letter, .footer-instagram .instagram-username',
				'property' => 'border-radius',
			),
		) ),
	)
);

