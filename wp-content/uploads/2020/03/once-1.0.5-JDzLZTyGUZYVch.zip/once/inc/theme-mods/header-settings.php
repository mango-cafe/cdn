<?php
/**
 * Header Settings
 *
 * @package Once
 */

CSCO_Kirki::add_section(
	'header', array(
		'title'    => esc_html__( 'Header Settings', 'once' ),
		'priority' => 40,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'collapsible',
		'settings' => 'header_collapsible_general',
		'label'    => esc_html__( 'General', 'once' ),
		'section'  => 'header',
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'radio',
		'settings' => 'header_layout',
		'label'    => esc_html__( 'Layout', 'once' ),
		'section'  => 'header',
		'default'  => 'compact',
		'priority' => 10,
		'choices'  => array(
			'compact'      => esc_html__( 'Compact', 'once' ),
			'with-top-bar' => esc_html__( 'With top bar', 'once' ),
			'large'        => esc_html__( 'Large', 'once' ),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'radio',
		'settings'        => 'header_top_content',
		'label'           => esc_html__( 'Topbar Content', 'once' ),
		'section'         => 'header',
		'default'         => 'subscription',
		'priority'        => 10,
		'choices'         => array(
			'subscription' => esc_html__( 'Subscription Form', 'once' ),
			'additional'   => esc_html__( 'Additional Menu', 'once' ),
		),
		'active_callback' => array(
			array(
				'setting'  => 'header_layout',
				'operator' => '==',
				'value'    => 'with-top-bar',
			),
		),
	)
);

if ( csco_powerkit_module_enabled( 'opt_in_forms' ) ) {
	CSCO_Kirki::add_field(
		'csco_theme_mod', array(
			'type'              => 'text',
			'settings'          => 'header_subscribe_title',
			'label'             => esc_html__( 'Subscription Title', 'once' ),
			'section'           => 'header',
			'default'           => '<span>' . esc_html__( 'Subscribe', 'once' ) . '</span> ' . esc_html__( 'for New Stories', 'once' ),
			'priority'          => 10,
			'sanitize_callback' => 'wp_kses_post',
			'active_callback'   => array(
				array(
					'setting'  => 'header_layout',
					'operator' => '==',
					'value'    => 'with-top-bar',
				),
				array(
					'setting'  => 'header_top_content',
					'operator' => '==',
					'value'    => 'subscription',
				),
			),
		)
	);
}

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'checkbox',
		'settings' => 'header_shadow_submenus',
		'label'    => esc_html__( 'Display shadow on submenus', 'once' ),
		'section'  => 'header',
		'default'  => false,
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'checkbox',
		'settings' => 'header_navigation_menu',
		'label'    => esc_html__( 'Display navigation menu', 'once' ),
		'section'  => 'header',
		'default'  => true,
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'checkbox',
		'settings'        => 'header_tagline',
		'label'           => esc_html__( 'Display tagline', 'once' ),
		'section'         => 'header',
		'default'         => false,
		'priority'        => 10,
		'active_callback' => array(
			array(
				'setting'  => 'header_layout',
				'operator' => '==',
				'value'    => 'large',
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'dimension',
		'settings'        => 'header_height',
		'label'           => esc_html__( 'Header Height', 'once' ),
		'section'         => 'header',
		'default'         => 'auto',
		'priority'        => 10,
		'output'          => array(
			array(
				'element'  => '.navbar-topbar .navbar-wrap',
				'property' => 'min-height',
			),
		),
		'active_callback' => array(
			array(
				'setting'  => 'header_layout',
				'operator' => '==',
				'value'    => 'large',
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'dimension',
		'settings' => 'header_nav_height',
		'label'    => esc_html__( 'Navigation Bar Height', 'once' ),
		'section'  => 'header',
		'default'  => '80px',
		'priority' => 10,
		'output'   => array(
			array(
				'element'  => '.navbar-primary .navbar-wrap, .navbar-primary .navbar-content',
				'property' => 'height',
			),
			array(
				'element'       => '.offcanvas-header',
				'property'      => 'flex',
				'value_pattern' => '0 0 $',
			),
			array(
				'element'       => '.post-sidebar-shares',
				'property'      => 'top',
				'value_pattern' => 'calc( $ + 20px )',
			),
			array(
				'element'       => '.admin-bar .post-sidebar-shares',
				'property'      => 'top',
				'value_pattern' => 'calc( $ + 52px )',
			),
			array(
				'element'       => '.header-large .post-sidebar-shares',
				'property'      => 'top',
				'value_pattern' => 'calc( $ * 2 + 52px )',
			),
			array(
				'element'       => '.header-large.admin-bar .post-sidebar-shares',
				'property'      => 'top',
				'value_pattern' => 'calc( $ * 2 + 52px )',
			),
		),
	)
);


CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'        => 'checkbox',
		'settings'    => 'navbar_sticky',
		'label'       => esc_html__( 'Make navigation bar sticky', 'once' ),
		'description' => esc_html__( 'Enabling this option will make navigation bar visible when scrolling.', 'once' ),
		'section'     => 'header',
		'default'     => true,
		'priority'    => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'checkbox',
		'settings'        => 'effects_navbar_scroll',
		'label'           => esc_html__( 'Enable the smart sticky feature', 'once' ),
		'description'     => esc_html__( 'Enabling this option will reveal navigation bar when scrolling up and hide it when scrolling down.', 'once' ),
		'section'         => 'header',
		'default'         => true,
		'priority'        => 10,
		'active_callback' => array(
			array(
				'setting'  => 'navbar_sticky',
				'operator' => '==',
				'value'    => true,
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'checkbox',
		'settings' => 'header_offcanvas',
		'label'    => esc_html__( 'Display offcanvas toggle button', 'once' ),
		'section'  => 'header',
		'default'  => true,
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'checkbox',
		'settings' => 'header_search_button',
		'label'    => esc_html__( 'Display search button', 'once' ),
		'section'  => 'header',
		'default'  => true,
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'radio',
		'settings' => 'header_image_orientation',
		'label'    => esc_html__( 'Mega Menu Image Orientation', 'once' ),
		'section'  => 'header',
		'default'  => 'landscape',
		'priority' => 10,
		'choices'  => array(
			'original'  => esc_html__( 'Original', 'once' ),
			'landscape' => esc_html__( 'Landscape', 'once' ),
			'square'    => esc_html__( 'Square', 'once' ),
			'portrait'  => esc_html__( 'Portrait', 'once' ),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'radio',
		'settings' => 'header_mega_menu_layout',
		'label'    => esc_html__( 'Mega Menu Subcategories Layout', 'once' ),
		'section'  => 'header',
		'default'  => 'horizontal',
		'priority' => 10,
		'choices'  => array(
			'vertical'   => esc_html__( 'Vertical list', 'once' ),
			'horizontal' => esc_html__( 'Horizontal list', 'once' ),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'collapsible',
		'settings' => 'header_collapsible_button',
		'label'    => esc_html__( 'Button Link', 'once' ),
		'section'  => 'header',
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'              => 'text',
		'settings'          => 'header_follow_button_label',
		'label'             => esc_html__( 'Button Label', 'once' ),
		'section'           => 'header',
		'default'           => '<i class="cs-icon cs-icon-mail"></i>' . esc_html__( 'Subscribe', 'once' ),
		'priority'          => 10,
		'sanitize_callback' => 'wp_kses_post',
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'text',
		'settings' => 'header_follow_button_link',
		'label'    => esc_html__( 'Button Link', 'once' ),
		'section'  => 'header',
		'default'  => '',
		'priority' => 10,
	)
);

if ( csco_powerkit_module_enabled( 'social_links' ) ) {
	CSCO_Kirki::add_field(
		'csco_theme_mod', array(
			'type'     => 'collapsible',
			'settings' => 'header_collapsible_social',
			'label'    => esc_html__( 'Social Links', 'once' ),
			'section'  => 'header',
			'priority' => 10,
		)
	);

	CSCO_Kirki::add_field(
		'csco_theme_mod', array(
			'type'     => 'checkbox',
			'settings' => 'header_social_links',
			'label'    => esc_html__( 'Display social links', 'once' ),
			'section'  => 'header',
			'default'  => false,
			'priority' => 10,
		)
	);

	CSCO_Kirki::add_field(
		'csco_theme_mod', array(
			'type'            => 'select',
			'settings'        => 'header_social_links_scheme',
			'label'           => esc_html__( 'Color scheme', 'once' ),
			'section'         => 'header',
			'default'         => 'light',
			'priority'        => 10,
			'choices'         => array(
				'light'         => esc_html__( 'Light', 'once' ),
				'bold'          => esc_html__( 'Bold', 'once' ),
				'light-rounded' => esc_html__( 'Light Rounded', 'once' ),
				'bold-rounded'  => esc_html__( 'Bold Rounded', 'once' ),
			),
			'active_callback' => array(
				array(
					'setting'  => 'header_social_links',
					'operator' => '==',
					'value'    => true,
				),
			),
		)
	);

	CSCO_Kirki::add_field(
		'csco_theme_mod', array(
			'type'            => 'number',
			'settings'        => 'header_social_links_maximum',
			'label'           => esc_html__( 'Maximum Number of Social Links', 'once' ),
			'section'         => 'header',
			'default'         => 3,
			'priority'        => 10,
			'active_callback' => array(
				array(
					'setting'  => 'header_social_links',
					'operator' => '==',
					'value'    => true,
				),
			),
		)
	);

	CSCO_Kirki::add_field(
		'csco_theme_mod', array(
			'type'            => 'checkbox',
			'settings'        => 'header_social_links_counts',
			'label'           => esc_html__( 'Display social counts', 'once' ),
			'section'         => 'header',
			'default'         => true,
			'priority'        => 10,
			'active_callback' => array(
				array(
					'setting'  => 'header_social_links',
					'operator' => '==',
					'value'    => true,
				),
			),
		)
	);
}
