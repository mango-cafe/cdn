<?php
/**
 * Homepage Settings
 *
 * @package Once
 */

/**
 * Removes default WordPress Static Front Page section
 * and re-adds it in our own panel with the same parameters.
 *
 * @param object $wp_customize Instance of the WP_Customize_Manager class.
 */
function csco_reorder_customizer_settings( $wp_customize ) {

	// Get current front page section parameters.
	$static_front_page = $wp_customize->get_section( 'static_front_page' );

	// Remove existing section, so that we can later re-add it to our panel.
	$wp_customize->remove_section( 'static_front_page' );

	// Re-add static front page section with a new name, but same description.
	$wp_customize->add_section( 'static_front_page', array(
		'title'           => esc_html__( 'Static Front Page', 'once' ),
		'priority'        => 20,
		'description'     => $static_front_page->description,
		'panel'           => 'homepage_settings',
		'active_callback' => $static_front_page->active_callback,
	) );
}
add_action( 'customize_register', 'csco_reorder_customizer_settings' );

CSCO_Kirki::add_panel(
	'homepage_settings', array(
		'title'    => esc_html__( 'Homepage Settings', 'once' ),
		'priority' => 50,
	)
);

CSCO_Kirki::add_section(
	'homepage_layout', array(
		'title'    => esc_html__( 'Homepage Layout', 'once' ),
		'priority' => 15,
		'panel'    => 'homepage_settings',
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'radio',
		'settings' => 'home_layout',
		'label'    => esc_html__( 'Layout', 'once' ),
		'section'  => 'homepage_layout',
		'default'  => 'masonry',
		'priority' => 10,
		'choices'  => array(
			'full'    => esc_html__( 'Full Post Layout', 'once' ),
			'list'    => esc_html__( 'List Layout', 'once' ),
			'grid'    => esc_html__( 'Grid Layout', 'once' ),
			'masonry' => esc_html__( 'Masonry Layout', 'once' ),
			'mixed'   => esc_html__( 'Mixed Layout', 'once' ),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'radio',
		'settings' => 'home_sidebar',
		'label'    => esc_html__( 'Sidebar', 'once' ),
		'section'  => 'homepage_layout',
		'default'  => 'right',
		'priority' => 10,
		'choices'  => array(
			'right'    => esc_html__( 'Right Sidebar', 'once' ),
			'left'     => esc_html__( 'Left Sidebar', 'once' ),
			'disabled' => esc_html__( 'No Sidebar', 'once' ),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'radio',
		'settings'        => 'home_image_orientation',
		'label'           => esc_html__( 'Image Orientation', 'once' ),
		'section'         => 'homepage_layout',
		'default'         => 'original',
		'priority'        => 10,
		'choices'         => array(
			'original'  => esc_html__( 'Original', 'once' ),
			'landscape' => esc_html__( 'Landscape', 'once' ),
			'square'    => esc_html__( 'Square', 'once' ),
			'portrait'  => esc_html__( 'Portrait', 'once' ),
		),
		'active_callback' => array(
			array(
				array(
					'setting'  => 'home_layout',
					'operator' => '==',
					'value'    => 'list',
				),
				array(
					'setting'  => 'home_layout',
					'operator' => '==',
					'value'    => 'grid',
				),
				array(
					'setting'  => 'home_layout',
					'operator' => '==',
					'value'    => 'masonry',
				),
				array(
					'setting'  => 'home_layout',
					'operator' => '==',
					'value'    => 'mixed',
				),
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'multicheck',
		'settings' => 'home_post_meta',
		'label'    => esc_html__( 'Post Meta', 'once' ),
		'section'  => 'homepage_layout',
		'default'  => array( 'category', 'author', 'date', 'views', 'reading_time' ),
		'priority' => 10,
		'choices'  => apply_filters( 'csco_post_meta_choices', array(
			'category'     => esc_html__( 'Category', 'once' ),
			'author'       => esc_html__( 'Author', 'once' ),
			'date'         => esc_html__( 'Date', 'once' ),
			'views'        => esc_html__( 'Views', 'once' ),
			'shares'       => esc_html__( 'Shares', 'once' ),
			'comments'     => esc_html__( 'Comments', 'once' ),
			'reading_time' => esc_html__( 'Reading Time', 'once' ),
		) ),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'checkbox',
		'settings'        => 'home_group_category_title',
		'label'           => esc_html__( 'Group category and post title', 'once' ),
		'section'         => 'homepage_layout',
		'default'         => true,
		'priority'        => 10,
		'active_callback' => array(
			array(
				array(
					'setting'  => 'home_layout',
					'operator' => '==',
					'value'    => 'list',
				),
				array(
					'setting'  => 'home_layout',
					'operator' => '==',
					'value'    => 'grid',
				),
				array(
					'setting'  => 'home_layout',
					'operator' => '==',
					'value'    => 'masonry',
				),
				array(
					'setting'  => 'home_layout',
					'operator' => '==',
					'value'    => 'mixed',
				),
			),
			array(
				'setting'  => 'home_post_meta',
				'operator' => 'in',
				'value'    => 'category',
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'checkbox',
		'settings'        => 'home_group_author_date',
		'label'           => esc_html__( 'Group post author and date', 'once' ),
		'section'         => 'homepage_layout',
		'default'         => true,
		'priority'        => 10,
		'active_callback' => array(
			array(
				array(
					'setting'  => 'home_layout',
					'operator' => '==',
					'value'    => 'list',
				),
				array(
					'setting'  => 'home_layout',
					'operator' => '==',
					'value'    => 'grid',
				),
				array(
					'setting'  => 'home_layout',
					'operator' => '==',
					'value'    => 'masonry',
				),
				array(
					'setting'  => 'home_layout',
					'operator' => '==',
					'value'    => 'mixed',
				),
			),
			array(
				'setting'  => 'home_post_meta',
				'operator' => 'in',
				'value'    => 'author',
			),
			array(
				'setting'  => 'home_post_meta',
				'operator' => 'in',
				'value'    => 'date',
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'radio',
		'settings'        => 'home_group_author_date_position',
		'label'           => esc_html__( 'Group Post Author and Date Position', 'once' ),
		'section'         => 'homepage_layout',
		'default'         => 'above',
		'priority'        => 10,
		'choices'         => array(
			'above' => esc_html__( 'Above post title', 'once' ),
			'below' => esc_html__( 'Below post summary', 'once' ),
		),
		'active_callback' => array(
			array(
				array(
					'setting'  => 'home_layout',
					'operator' => '==',
					'value'    => 'list',
				),
				array(
					'setting'  => 'home_layout',
					'operator' => '==',
					'value'    => 'grid',
				),
				array(
					'setting'  => 'home_layout',
					'operator' => '==',
					'value'    => 'masonry',
				),
				array(
					'setting'  => 'home_layout',
					'operator' => '==',
					'value'    => 'mixed',
				),
			),
			array(
				'setting'  => 'home_post_meta',
				'operator' => 'in',
				'value'    => 'author',
			),
			array(
				'setting'  => 'home_post_meta',
				'operator' => 'in',
				'value'    => 'date',
			),
			array(
				'setting'  => 'home_group_author_date',
				'operator' => '==',
				'value'    => true,
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'radio',
		'settings'        => 'homepage_media_preview',
		'label'           => esc_html__( 'Post Preview Image Size', 'once' ),
		'section'         => 'homepage_layout',
		'default'         => 'cropped',
		'priority'        => 10,
		'choices'         => array(
			'cropped'   => esc_html__( 'Display Cropped Image', 'once' ),
			'uncropped' => esc_html__( 'Display Preview in Original Ratio', 'once' ),
		),
		'active_callback' => array(
			array(
				'setting'  => 'home_layout',
				'operator' => '==',
				'value'    => 'full',
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'radio',
		'settings'        => 'home_summary',
		'label'           => esc_html__( 'Full Post Summary', 'once' ),
		'section'         => 'homepage_layout',
		'default'         => 'excerpt',
		'priority'        => 10,
		'choices'         => array(
			'excerpt' => esc_html__( 'Use Excerpts', 'once' ),
			'content' => esc_html__( 'Use Read More Tag', 'once' ),
		),
		'active_callback' => array(
			array(
				'setting'  => 'home_layout',
				'operator' => '==',
				'value'    => 'full',
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'checkbox',
		'settings' => 'home_excerpt',
		'label'    => esc_html__( 'Display excerpts', 'once' ),
		'section'  => 'homepage_layout',
		'default'  => true,
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'checkbox',
		'settings' => 'home_more_button',
		'label'    => esc_html__( 'Display read more button', 'once' ),
		'section'  => 'homepage_layout',
		'default'  => false,
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'radio',
		'settings' => 'home_pagination_type',
		'label'    => esc_html__( 'Pagination', 'once' ),
		'section'  => 'homepage_layout',
		'default'  => 'load-more',
		'priority' => 10,
		'choices'  => array(
			'standard'  => esc_html__( 'Standard', 'once' ),
			'load-more' => esc_html__( 'Load More Button', 'once' ),
			'infinite'  => esc_html__( 'Infinite Load', 'once' ),
		),
	)
);

CSCO_Kirki::add_section(
	'featured', array(
		'title'    => esc_html__( 'Featured Post', 'once' ),
		'panel'    => 'homepage_settings',
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'radio',
		'settings' => 'featured_layout',
		'label'    => esc_html__( 'Layout', 'once' ),
		'section'  => 'featured',
		'default'  => 'small',
		'priority' => 10,
		'choices'  => array(
			'default'  => esc_html__( 'Inherit from post header', 'once' ),
			'small'    => esc_html__( 'Small', 'once' ),
			'boxed'    => esc_html__( 'Boxed', 'once' ),
			'standard' => esc_html__( 'Standard', 'once' ),
			'large'    => esc_html__( 'Large', 'once' ),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'radio',
		'settings'        => 'featured_location',
		'label'           => esc_html__( 'Display Location', 'once' ),
		'section'         => 'featured',
		'default'         => 'front_page',
		'priority'        => 10,
		'choices'         => array(
			'front_page' => esc_html__( 'Homepage', 'once' ),
			'home'       => esc_html__( 'Posts page', 'once' ),
		),
		'active_callback' => array(
			array(
				'setting'  => 'show_on_front',
				'operator' => '==',
				'value'    => 'page',
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'color',
		'settings' => 'featured_background',
		'label'    => esc_html__( 'Background Color', 'once' ),
		'section'  => 'featured',
		'priority' => 10,
		'default'  => '#FFFFFF',
		'output'   => array(
			array(
				'element'  => '.section-featured-post',
				'property' => 'background-color',
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'multicheck',
		'settings' => 'featured_meta',
		'label'    => esc_attr__( 'Post Meta', 'once' ),
		'section'  => 'featured',
		'default'  => array( 'category', 'author', 'date' ),
		'priority' => 10,
		'choices'  => apply_filters( 'csco_post_meta_choices', array(
			'category'     => esc_html__( 'Category', 'once' ),
			'author'       => esc_html__( 'Author', 'once' ),
			'date'         => esc_html__( 'Date', 'once' ),
			'views'        => esc_html__( 'Views', 'once' ),
			'shares'       => esc_html__( 'Shares', 'once' ),
			'comments'     => esc_html__( 'Comments', 'once' ),
			'reading_time' => esc_html__( 'Reading Time', 'once' ),
		) ),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'checkbox',
		'settings'        => 'featured_group_category_title',
		'label'           => esc_html__( 'Group category and post title', 'once' ),
		'section'         => 'featured',
		'default'         => false,
		'priority'        => 10,
		'active_callback' => array(
			array(
				'setting'  => 'featured_meta',
				'operator' => 'in',
				'value'    => 'category',
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'checkbox',
		'settings' => 'featured_excerpt',
		'label'    => esc_html__( 'Display excerpts', 'once' ),
		'section'  => 'featured',
		'default'  => true,
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'        => 'text',
		'settings'    => 'featured_filter_categories',
		'label'       => esc_html__( 'Filter by Categories', 'once' ),
		'description' => esc_html__( 'Add comma-separated list of category slugs. For example: &laquo;travel, lifestyle, food&raquo;. Leave empty for all categories.', 'once' ),
		'section'     => 'featured',
		'default'     => '',
		'priority'    => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'        => 'text',
		'settings'    => 'featured_filter_tags',
		'label'       => esc_html__( 'Filter by Tags', 'once' ),
		'description' => esc_html__( 'Add comma-separated list of tag slugs. For example: &laquo;worth-reading, top-5, playlists&raquo;. Leave empty for all tags.', 'once' ),
		'section'     => 'featured',
		'default'     => '',
		'priority'    => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'        => 'text',
		'settings'    => 'featured_filter_posts',
		'label'       => esc_html__( 'Filter by Posts', 'once' ),
		'description' => esc_html__( 'Add comma-separated list of post IDs. For example: 12, 34, 145. Leave empty for all posts.', 'once' ),
		'section'     => 'featured',
		'default'     => '',
		'priority'    => 10,
	)
);

if ( class_exists( 'Post_Views_Counter' ) ) {

	CSCO_Kirki::add_field(
		'csco_theme_mod', array(
			'type'     => 'radio',
			'settings' => 'featured_orderby',
			'label'    => esc_html__( 'Order posts by', 'once' ),
			'section'  => 'featured',
			'default'  => 'date',
			'priority' => 10,
			'choices'  => array(
				'date'       => esc_html__( 'Date', 'once' ),
				'post_views' => esc_html__( 'Views', 'once' ),
			),
		)
	);

	CSCO_Kirki::add_field(
		'csco_theme_mod', array(
			'type'            => 'text',
			'settings'        => 'featured_time_frame',
			'label'           => esc_html__( 'Filter by Time Frame', 'once' ),
			'description'     => esc_html__( 'Add period of posts in English. For example: &laquo;2 months&raquo;, &laquo;14 days&raquo; or even &laquo;1 year&raquo;', 'once' ),
			'section'         => 'featured',
			'default'         => '',
			'priority'        => 10,
			'active_callback' => array(
				array(
					'setting'  => 'featured_orderby',
					'operator' => '==',
					'value'    => 'post_views',
				),
			),
		)
	);
}

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'checkbox',
		'settings' => 'featured_exclude',
		'label'    => esc_html__( 'Exclude featured posts from the main archive', 'once' ),
		'section'  => 'featured',
		'default'  => false,
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'        => 'checkbox',
		'settings'    => 'featured_avoid_duplicate',
		'label'       => esc_html__( 'Exclude duplicate posts from the post featured', 'once' ),
		'description' => esc_html__( 'If enabled, posts from the upper sections will not be shown in the post featured. The "Filter by Posts" option will override this option.', 'once' ),
		'section'     => 'featured',
		'default'     => false,
		'priority'    => 10,
	)
);

CSCO_Kirki::add_section(
	'tiles', array(
		'title'    => esc_html__( 'Post Tiles', 'once' ),
		'panel'    => 'homepage_settings',
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'radio',
		'settings' => 'tiles_type',
		'label'    => esc_html__( 'Type', 'once' ),
		'section'  => 'tiles',
		'default'  => 'type-1',
		'priority' => 10,
		'choices'  => array(
			'type-1' => esc_html__( 'Type 1', 'once' ),
			'type-2' => esc_html__( 'Type 2', 'once' ),
			'type-3' => esc_html__( 'Type 3', 'once' ),
			'type-4' => esc_html__( 'Type 4', 'once' ),
			'type-5' => esc_html__( 'Type 5', 'once' ),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'radio',
		'settings'        => 'tiles_location',
		'label'           => esc_html__( 'Display Location', 'once' ),
		'section'         => 'tiles',
		'default'         => 'front_page',
		'priority'        => 10,
		'choices'         => array(
			'front_page' => esc_html__( 'Homepage', 'once' ),
			'home'       => esc_html__( 'Posts page', 'once' ),
		),
		'active_callback' => array(
			array(
				'setting'  => 'show_on_front',
				'operator' => '==',
				'value'    => 'page',
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'color',
		'settings' => 'tiles_background',
		'label'    => esc_html__( 'Background Color', 'once' ),
		'section'  => 'tiles',
		'priority' => 10,
		'default'  => '#FFFFFF',
		'output'   => array(
			array(
				'element'  => '.section-post-tiles',
				'property' => 'background-color',
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'radio',
		'settings' => 'tiles_image_orientation',
		'label'    => esc_html__( 'Image Orientation', 'once' ),
		'section'  => 'tiles',
		'default'  => 'square',
		'priority' => 10,
		'choices'  => array(
			'original'  => esc_html__( 'Original', 'once' ),
			'landscape' => esc_html__( 'Landscape', 'once' ),
			'square'    => esc_html__( 'Square', 'once' ),
			'portrait'  => esc_html__( 'Portrait', 'once' ),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'multicheck',
		'settings' => 'tiles_simple_meta',
		'label'    => esc_attr__( 'Post Meta of Simple Posts', 'once' ),
		'section'  => 'tiles',
		'default'  => array( 'category', 'author' ),
		'priority' => 10,
		'choices'  => apply_filters( 'csco_post_meta_choices', array(
			'category'     => esc_html__( 'Category', 'once' ),
			'author'       => esc_html__( 'Author', 'once' ),
			'date'         => esc_html__( 'Date', 'once' ),
			'shares'       => esc_html__( 'Shares', 'once' ),
			'views'        => esc_html__( 'Views', 'once' ),
			'comments'     => esc_html__( 'Comments', 'once' ),
			'reading_time' => esc_html__( 'Reading Time', 'once' ),
		) ),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'checkbox',
		'settings'        => 'tiles_simple_group_category_title',
		'label'           => esc_html__( 'Group category and post title of simple posts', 'once' ),
		'section'         => 'tiles',
		'default'         => true,
		'priority'        => 10,
		'active_callback' => array(
			array(
				'setting'  => 'tiles_simple_meta',
				'operator' => 'in',
				'value'    => 'category',
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'multicheck',
		'settings' => 'tiles_full_meta',
		'label'    => esc_attr__( 'Post Meta of Large Posts', 'once' ),
		'section'  => 'tiles',
		'default'  => array( 'category', 'author', 'date' ),
		'priority' => 10,
		'choices'  => apply_filters( 'csco_post_meta_choices', array(
			'category'     => esc_html__( 'Category', 'once' ),
			'author'       => esc_html__( 'Author', 'once' ),
			'date'         => esc_html__( 'Date', 'once' ),
			'views'        => esc_html__( 'Views', 'once' ),
			'shares'       => esc_html__( 'Shares', 'once' ),
			'comments'     => esc_html__( 'Comments', 'once' ),
			'reading_time' => esc_html__( 'Reading Time', 'once' ),
		) ),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'checkbox',
		'settings'        => 'tiles_full_group_category_title',
		'label'           => esc_html__( 'Group category and post title of large posts', 'once' ),
		'section'         => 'tiles',
		'default'         => false,
		'priority'        => 10,
		'active_callback' => array(
			array(
				'setting'  => 'tiles_full_meta',
				'operator' => 'in',
				'value'    => 'category',
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'checkbox',
		'settings' => 'tiles_excerpt',
		'label'    => esc_html__( 'Display excerpts of large posts', 'once' ),
		'section'  => 'tiles',
		'default'  => true,
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'        => 'text',
		'settings'    => 'tiles_filter_categories',
		'label'       => esc_html__( 'Filter by Categories', 'once' ),
		'description' => esc_html__( 'Add comma-separated list of category slugs. For example: &laquo;travel, lifestyle, food&raquo;. Leave empty for all categories.', 'once' ),
		'section'     => 'tiles',
		'default'     => '',
		'priority'    => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'        => 'text',
		'settings'    => 'tiles_filter_tags',
		'label'       => esc_html__( 'Filter by Tags', 'once' ),
		'description' => esc_html__( 'Add comma-separated list of tag slugs. For example: &laquo;worth-reading, top-5, playlists&raquo;. Leave empty for all tags.', 'once' ),
		'section'     => 'tiles',
		'default'     => '',
		'priority'    => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'        => 'text',
		'settings'    => 'tiles_filter_posts',
		'label'       => esc_html__( 'Filter by Posts', 'once' ),
		'description' => esc_html__( 'Add comma-separated list of post IDs. For example: 12, 34, 145. Leave empty for all posts.', 'once' ),
		'section'     => 'tiles',
		'default'     => '',
		'priority'    => 10,
	)
);

if ( class_exists( 'Post_Views_Counter' ) ) {

	CSCO_Kirki::add_field(
		'csco_theme_mod', array(
			'type'     => 'radio',
			'settings' => 'tiles_orderby',
			'label'    => esc_html__( 'Order posts by', 'once' ),
			'section'  => 'tiles',
			'default'  => 'date',
			'priority' => 10,
			'choices'  => array(
				'date'       => esc_html__( 'Date', 'once' ),
				'post_views' => esc_html__( 'Views', 'once' ),
			),
		)
	);

	CSCO_Kirki::add_field(
		'csco_theme_mod', array(
			'type'            => 'text',
			'settings'        => 'tiles_time_frame',
			'label'           => esc_html__( 'Filter by Time Frame', 'once' ),
			'description'     => esc_html__( 'Add period of posts in English. For example: &laquo;2 months&raquo;, &laquo;14 days&raquo; or even &laquo;1 year&raquo;', 'once' ),
			'section'         => 'tiles',
			'default'         => '',
			'priority'        => 10,
			'active_callback' => array(
				array(
					'setting'  => 'tiles_orderby',
					'operator' => '==',
					'value'    => 'post_views',
				),
			),
		)
	);
}

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'checkbox',
		'settings' => 'tiles_exclude',
		'label'    => esc_html__( 'Exclude posts of tiles from the main archive', 'once' ),
		'section'  => 'tiles',
		'default'  => false,
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'        => 'checkbox',
		'settings'    => 'tiles_avoid_duplicate',
		'label'       => esc_html__( 'Exclude duplicate posts from the post tiles', 'once' ),
		'description' => esc_html__( 'If enabled, posts from the upper sections will not be shown in the post tiles. The "Filter by Posts" option will override this option.', 'once' ),
		'section'     => 'tiles',
		'default'     => false,
		'priority'    => 10,
	)
);

CSCO_Kirki::add_section(
	'carousel', array(
		'title'    => esc_html__( 'Post Carousel', 'once' ),
		'panel'    => 'homepage_settings',
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'radio',
		'settings'        => 'carousel_location',
		'label'           => esc_html__( 'Display Location', 'once' ),
		'section'         => 'carousel',
		'default'         => 'front_page',
		'priority'        => 10,
		'choices'         => array(
			'front_page' => esc_html__( 'Homepage', 'once' ),
			'home'       => esc_html__( 'Posts page', 'once' ),
		),
		'active_callback' => array(
			array(
				'setting'  => 'show_on_front',
				'operator' => '==',
				'value'    => 'page',
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'color',
		'settings' => 'carousel_background',
		'label'    => esc_html__( 'Background Color', 'once' ),
		'section'  => 'carousel',
		'priority' => 10,
		'default'  => '#FAFAFA',
		'output'   => array(
			array(
				'element'  => '.section-post-carousel',
				'property' => 'background-color',
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'              => 'textarea',
		'settings'          => 'carousel_title',
		'label'             => esc_html__( 'Title', 'once' ),
		'section'           => 'carousel',
		'default'           => esc_html__( 'Most Trending', 'once' ) . "\n" . esc_html__( 'Stories', 'once' ),
		'description'       => esc_html__( 'Insert a line break to style the second line differently.', 'once' ),
		'priority'          => 10,
		'sanitize_callback' => 'wp_kses_post',
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'number',
		'settings' => 'carousel_number_slides',
		'label'    => esc_html__( 'Number of Slides', 'once' ),
		'section'  => 'carousel',
		'default'  => 5,
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'radio',
		'settings' => 'carousel_image_orientation',
		'label'    => esc_html__( 'Image Orientation', 'once' ),
		'section'  => 'carousel',
		'default'  => 'square',
		'priority' => 10,
		'choices'  => array(
			'original'  => esc_html__( 'Original', 'once' ),
			'landscape' => esc_html__( 'Landscape', 'once' ),
			'square'    => esc_html__( 'Square', 'once' ),
			'portrait'  => esc_html__( 'Portrait', 'once' ),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'multicheck',
		'settings' => 'carousel_meta',
		'label'    => esc_attr__( 'Post Meta', 'once' ),
		'section'  => 'carousel',
		'default'  => array( 'category', 'author' ),
		'priority' => 10,
		'choices'  => apply_filters( 'csco_post_meta_choices', array(
			'category'     => esc_html__( 'Category', 'once' ),
			'author'       => esc_html__( 'Author', 'once' ),
			'date'         => esc_html__( 'Date', 'once' ),
			'views'        => esc_html__( 'Views', 'once' ),
			'shares'       => esc_html__( 'Shares', 'once' ),
			'comments'     => esc_html__( 'Comments', 'once' ),
			'reading_time' => esc_html__( 'Reading Time', 'once' ),
		) ),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'checkbox',
		'settings'        => 'carousel_group_category_title',
		'label'           => esc_html__( 'Group category and post title', 'once' ),
		'section'         => 'carousel',
		'default'         => true,
		'priority'        => 10,
		'active_callback' => array(
			array(
				'setting'  => 'carousel_meta',
				'operator' => 'in',
				'value'    => 'category',
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'        => 'text',
		'settings'    => 'carousel_filter_categories',
		'label'       => esc_html__( 'Filter by Categories', 'once' ),
		'description' => esc_html__( 'Add comma-separated list of category slugs. For example: &laquo;travel, lifestyle, food&raquo;. Leave empty for all categories.', 'once' ),
		'section'     => 'carousel',
		'default'     => '',
		'priority'    => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'        => 'text',
		'settings'    => 'carousel_filter_tags',
		'label'       => esc_html__( 'Filter by Tags', 'once' ),
		'description' => esc_html__( 'Add comma-separated list of tag slugs. For example: &laquo;worth-reading, top-5, playlists&raquo;. Leave empty for all tags.', 'once' ),
		'section'     => 'carousel',
		'default'     => '',
		'priority'    => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'        => 'text',
		'settings'    => 'carousel_filter_posts',
		'label'       => esc_html__( 'Filter by Posts', 'once' ),
		'description' => esc_html__( 'Add comma-separated list of post IDs. For example: 12, 34, 145. Leave empty for all posts.', 'once' ),
		'section'     => 'carousel',
		'default'     => '',
		'priority'    => 10,
	)
);

if ( class_exists( 'Post_Views_Counter' ) ) {

	CSCO_Kirki::add_field(
		'csco_theme_mod', array(
			'type'     => 'radio',
			'settings' => 'carousel_orderby',
			'label'    => esc_html__( 'Order posts by', 'once' ),
			'section'  => 'carousel',
			'default'  => 'date',
			'priority' => 10,
			'choices'  => array(
				'date'       => esc_html__( 'Date', 'once' ),
				'post_views' => esc_html__( 'Views', 'once' ),
			),
		)
	);

	CSCO_Kirki::add_field(
		'csco_theme_mod', array(
			'type'            => 'text',
			'settings'        => 'carousel_time_frame',
			'label'           => esc_html__( 'Filter by Time Frame', 'once' ),
			'description'     => esc_html__( 'Add period of posts in English. For example: &laquo;2 months&raquo;, &laquo;14 days&raquo; or even &laquo;1 year&raquo;', 'once' ),
			'section'         => 'carousel',
			'default'         => '',
			'priority'        => 10,
			'active_callback' => array(
				array(
					'setting'  => 'carousel_orderby',
					'operator' => '==',
					'value'    => 'post_views',
				),
			),
		)
	);
}

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'checkbox',
		'settings' => 'carousel_exclude',
		'label'    => esc_html__( 'Exclude posts of carousel from the main archive', 'once' ),
		'section'  => 'carousel',
		'default'  => false,
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'        => 'checkbox',
		'settings'    => 'carousel_avoid_duplicate',
		'label'       => esc_html__( 'Exclude duplicate posts from the post carousel', 'once' ),
		'description' => esc_html__( 'If enabled, posts from the upper sections will not be shown in the post carousel. The "Filter by Posts" option will override this option.', 'once' ),
		'section'     => 'carousel',
		'default'     => false,
		'priority'    => 10,
	)
);

if ( csco_powerkit_module_enabled( 'opt_in_forms' ) ) {
	CSCO_Kirki::add_section(
		'subscription', array(
			'title'    => esc_html__( 'Subscription Form', 'once' ),
			'panel'    => 'homepage_settings',
			'priority' => 10,
		)
	);

	CSCO_Kirki::add_field(
		'csco_theme_mod', array(
			'type'            => 'radio',
			'settings'        => 'subscription_location',
			'label'           => esc_html__( 'Display Location', 'once' ),
			'section'         => 'subscription',
			'default'         => 'front_page',
			'priority'        => 10,
			'choices'         => array(
				'front_page' => esc_html__( 'Homepage', 'once' ),
				'home'       => esc_html__( 'Posts page', 'once' ),
			),
			'active_callback' => array(
				array(
					'setting'  => 'show_on_front',
					'operator' => '==',
					'value'    => 'page',
				),
			),
		)
	);

	CSCO_Kirki::add_field(
		'csco_theme_mod', array(
			'type'     => 'color',
			'settings' => 'subscription_background',
			'label'    => esc_html__( 'Background Color', 'once' ),
			'section'  => 'subscription',
			'priority' => 10,
			'default'  => '#FAFAFA',
			'output'   => array(
				array(
					'element'  => '.section-subscription',
					'property' => 'background-color',
				),
			),
		)
	);

	CSCO_Kirki::add_field(
		'csco_theme_mod', array(
			'type'     => 'checkbox',
			'settings' => 'subscription_name',
			'label'    => esc_html__( 'Display first name field', 'once' ),
			'section'  => 'subscription',
			'default'  => true,
			'priority' => 10,
		)
	);

	CSCO_Kirki::add_field(
		'csco_theme_mod', array(
			'type'              => 'textarea',
			'settings'          => 'subscription_title',
			'label'             => esc_html__( 'Title', 'once' ),
			'section'           => 'subscription',
			'default'           => esc_html__( 'Subscribe to Get Our', 'once' ) . "\n" . esc_html__( 'Newsletter', 'once' ),
			'description'       => esc_html__( 'Insert a line break to style the second line differently.', 'once' ),
			'priority'          => 10,
			'sanitize_callback' => 'wp_kses_post',
		)
	);
}

CSCO_Kirki::add_section(
	'sections_order', array(
		'title'    => esc_html__( 'Sections Order', 'once' ),
		'panel'    => 'homepage_settings',
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'sortable',
		'settings' => 'homepage_components',
		'label'    => esc_html__( 'Components', 'once' ),
		'section'  => 'sections_order',
		'default'  => csco_homepage_components_default(),
		'choices'  => csco_homepage_components_choices(),
		'priority' => 10,
	)
);
