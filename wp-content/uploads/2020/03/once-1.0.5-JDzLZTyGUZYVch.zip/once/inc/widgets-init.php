<?php
/**
 * Widgets Init
 *
 * Register sitebar locations for widgets.
 *
 * @package Once
 */

if ( ! function_exists( 'csco_widgets_init' ) ) {
	/**
	 * Register widget areas.
	 *
	 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
	 */
	function csco_widgets_init() {

		$tag = apply_filters( 'csco_section_title_tag', 'h5' );

		register_sidebar(
			array(
				'name'          => esc_html__( 'Default Sidebar', 'once' ),
				'id'            => 'sidebar-main',
				'before_widget' => '<div class="widget %1$s %2$s">',
				'after_widget'  => '</div>',
				'before_title'  => '<div class="title-block-wrap"><' . $tag . ' class="title-block title-widget">',
				'after_title'   => '</' . $tag . '></div>',
			)
		);

		register_sidebar(
			array(
				'name'          => esc_html__( 'Off-Canvas', 'once' ),
				'id'            => 'sidebar-offcanvas',
				'before_widget' => '<div class="widget %1$s %2$s">',
				'after_widget'  => '</div>',
				'before_title'  => '<div class="title-block-wrap"><' . $tag . ' class="title-block title-widget">',
				'after_title'   => '</' . $tag . '></div>',
			)
		);

		register_sidebar(
			array(
				'name'          => esc_html__( 'Auto Loaded Sidebar', 'once' ),
				'id'            => 'sidebar-loaded',
				'before_widget' => '<div class="widget %1$s %2$s">',
				'after_widget'  => '</div>',
				'before_title'  => '<div class="title-block-wrap"><' . $tag . ' class="title-block title-widget">',
				'after_title'   => '</' . $tag . '></div>',
			)
		);
	}
}
add_action( 'widgets_init', 'csco_widgets_init' );

if ( ! function_exists( 'csco_dynamic_sidebar_params' ) ) {
	/**
	 * Filters the parameters passed to a widget’s display callback.
	 *
	 * @param array $params An array of widget display arguments.
	 */
	function csco_dynamic_sidebar_params( $params ) {

		foreach ( $params as $key => $settings ) {

			if ( ! isset( $settings['widget_id'] ) || ! isset( $settings['before_widget'] ) ) {
				continue;
			}

			// Add support flickity to featured widget posts.
			if ( strpos( $settings['before_widget'], 'powerkit_widget_posts' ) ) {
				$params[ $key ]['before_widget'] = str_replace( 'widget ', 'widget cs-flickity-init ', $settings['before_widget'] );
			}

			// Add support scheme to subscription widget.
			if ( strpos( $settings['before_widget'], 'powerkit_opt_in_subscription_widget' ) ) {
				$scheme = csco_light_or_dark( get_theme_mod( 'color_accent', '#FAFAFA' ), ' ', ' cs-bg-dark ' );

				$params[ $key ]['before_widget'] = str_replace( 'widget ', 'widget' . $scheme, $settings['before_widget'] );
			}

			// Add support scheme to search widget.
			if ( strpos( $settings['before_widget'], 'widget_search' ) ) {
				$scheme = csco_light_or_dark( get_theme_mod( 'color_accent', '#FAFAFA' ), ' ', ' cs-bg-dark ' );

				$params[ $key ]['before_widget'] = str_replace( 'widget ', 'widget' . $scheme, $settings['before_widget'] );
			}

			// Add support scheme to social links widget.
			if ( strpos( $settings['before_widget'], 'powerkit_social_links_widget' ) ) {
				$scheme = csco_light_or_dark( get_theme_mod( 'color_accent', '#FAFAFA' ), ' ', ' cs-bg-social-links-dark ' );

				$params[ $key ]['before_widget'] = str_replace( 'widget ', 'widget' . $scheme, $settings['before_widget'] );
			}
		}

		return $params;
	}
}
add_filter( 'dynamic_sidebar_params', 'csco_dynamic_sidebar_params' );
