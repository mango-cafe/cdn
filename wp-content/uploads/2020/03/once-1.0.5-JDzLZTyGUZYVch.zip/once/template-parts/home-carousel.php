<?php
/**
 * Template part for displaying carousel section.
 *
 * @package Once
 */

$ids = csco_get_carousel_ids();

if ( $ids ) {
	$args = array(
		'ignore_sticky_posts' => true,
		'post__in'            => $ids,
		'posts_per_page'      => count( $ids ),
		'post_type'           => array( 'post', 'page' ),
		'orderby'             => 'post__in',
	);

	$the_query = new WP_Query( $args );
}

// Determines whether there are more posts available in the loop.
if ( $ids && $the_query->have_posts() ) {
	do_action( 'csco_post_carousel_before' );

	// Get background color.
	$background = get_theme_mod( 'carousel_background', '#FAFAFA' );

	// Set section class.
	$class = csco_section_class( 'section-post-carousel', $background );
	?>

	<div class="<?php echo esc_attr( $class ); ?>">

		<?php do_action( 'csco_post_carousel_start' ); ?>

			<div class="cs-post-carousel cs-flickity-init">

				<div class="cs-post-carousel-sidebar">

					<div class="cs-post-carousel-info">
						<?php
						$title = get_theme_mod( 'carousel_title', esc_html__( 'Most Trending', 'once' ) . "\n" . esc_html__( 'Stories', 'once' ) );

						if ( $title ) {
							?>
							<h3 class="cs-carousel-title"><?php echo wp_kses( nl2br( $title ), 'post' ); ?></h3>
							<?php
						}
						?>

						<div class="cs-post-carousel-arrows">
							<a href="#" class="carousel-arrow carousel-previous"></a>
							<a href="#" class="carousel-arrow carousel-next"></a>
						</div>
					</div>

				</div>

				<div class="cs-post-carousel-items">
					<?php
					while ( $the_query->have_posts() ) :
						$the_query->the_post();

						// Get image orientation.
						$orientation = get_theme_mod( 'carousel_image_orientation', 'square' );

						// Set ratio.
						$ratio = csco_get_image_ratio( $orientation );

						$image_size = csco_get_image_size_by( 'csco-thumbnail', $orientation );

						$group_cat_title = get_theme_mod( 'carousel_group_category_title', true );
					?>
						<article <?php post_class(); ?>>

							<div class="post-wrap">

								<div class="post-outer">

									<div class="post-inner entry-thumbnail">
										<div class="cs-overlay cs-overlay-transparent cs-overlay-ratio <?php echo esc_attr( $ratio ); ?>">
											<div class="<?php echo esc_attr( csco_get_overlay_type( $orientation ) ); ?>">
												<?php
												the_post_thumbnail( $image_size, array(
													'class' => 'pk-lazyload-disabled',
												) );
												?>
												<?php csco_get_video_background( 'tiles', null, 'default', true, true ); ?>
											</div>
											<?php if ( get_post_format() && 'post' === get_post_type() ) { ?>
												<div class="cs-overlay-content">
													<?php csco_the_post_format_icon(); ?>
												</div>
											<?php } ?>
											<a href="<?php the_permalink(); ?>" class="cs-overlay-link"></a>
										</div>
									</div>

									<div class="post-inner entry-inner entry-data">
										<?php if ( get_the_title() ) { ?>
											<header class="entry-header">
												<?php csco_post_cat_and_title( 'h2', 'carousel_meta', $group_cat_title ); ?>
											</header>
										<?php } ?>

										<?php
										if ( 'post' === get_post_type() ) {
											$post_meta_kit = array( 'author', 'date', 'views', 'shares', 'comments', 'reading_time' );

											if ( ! $group_cat_title ) {
												array_unshift( $post_meta_kit, 'category' );
											}

											csco_get_post_meta( $post_meta_kit, false, true, 'carousel_meta' );
										}
										?>
									</div>

								</div>

							</div>

						</article>

					<?php endwhile; ?>
				</div>

			</div>

			<?php wp_reset_postdata(); ?>

		<?php do_action( 'csco_post_carousel_end' ); ?>

	</div>

	<?php
	do_action( 'csco_post_carousel_after' );
}
