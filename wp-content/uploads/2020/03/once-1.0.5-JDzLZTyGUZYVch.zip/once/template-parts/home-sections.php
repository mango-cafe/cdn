<?php
/**
 * Homepage Sections.
 *
 * @package Once
 */

// Get available homepage components.
$components = get_theme_mod( 'homepage_components', csco_homepage_components_default() );

if ( $components && is_array( $components ) ) {

	// Loop through the components.
	foreach ( $components as $component ) {

		// Get Featured Post component template part.
		if ( 'featured' === $component ) {
			csco_homepage_featured();
		}

		// Get Post Tiles component template part.
		if ( 'tiles' === $component ) {
			csco_homepage_tiles();
		}

		// Get Post Carousel component template part.
		if ( 'carousel' === $component ) {
			csco_homepage_carousel();
		}

		// Get Subscribe component template part.
		if ( 'subscription' === $component ) {
			csco_homepage_subscription();
		}
	}
}
