<?php
/**
 * Template part for content of tile
 *
 * @package Once
 */

global $wp_query;

$query = get_query_var( 'csco_tile_query' );

$query->the_post();

// Get type of tiles.
$type = get_theme_mod( 'tiles_type', 'type-1' );

// Get thumbnail attr.
$thumbnail_attr = get_query_var( 'csco_tile_thumb_attr' );

// Get layout.
$layout = get_query_var( 'csco_tile_layout' );

// Add new classes.
$class = sprintf( 'layout-%s', $layout );

// Get image orientation.
$orientation = get_theme_mod( 'tiles_image_orientation', 'square' );

// Set ratio.
$ratio = csco_get_image_ratio( $orientation );

// Image size.
$image_size = 'csco-thumbnail';

if ( 'type-1' === $type ) {
	if ( 'tile-full' === $layout ) {
		$image_size = 'csco-thumbnail-large';
	}
	if ( 'tile-grid' === $layout ) {
		$image_size = 'csco-thumbnail-small';
	}
} elseif ( 'type-2' === $type ) {
	if ( 'tile-full' === $layout ) {
		$image_size = 'csco-medium';
	}
	if ( 'tile-grid' === $layout ) {
		$image_size = 'csco-thumbnail';
	}
} elseif ( 'type-3' === $type ) {
	if ( 'tile-full' === $layout ) {
		$image_size = 'csco-medium';
	}
	if ( 'tile-list' === $layout ) {
		$image_size = 'csco-intermediate';
	}
}

$image_size = csco_get_image_size_by( $image_size, $orientation );
?>

<article <?php post_class( $class ); ?>>

	<div class="post-wrap">

		<div class="post-outer">

			<div class="post-inner entry-thumbnail">
				<div class="cs-overlay cs-overlay-transparent cs-overlay-ratio <?php echo esc_attr( $ratio ); ?>">
					<div class="<?php echo esc_attr( csco_get_overlay_type( $orientation ) ); ?>">
						<?php the_post_thumbnail( $image_size, (array) $thumbnail_attr ); ?>
						<?php csco_get_video_background( 'tiles', null, 'default', true, ( 'tile-full' === $layout ) ); ?>
					</div>
					<?php if ( get_post_format() && 'post' === get_post_type() ) { ?>
						<div class="cs-overlay-content">
							<?php csco_the_post_format_icon(); ?>
						</div>
					<?php } ?>
					<a href="<?php the_permalink(); ?>" class="cs-overlay-link"></a>
				</div>
			</div>

			<?php
			if ( 'tile-full' === $layout ) {
				$group_cat_title = get_theme_mod( 'tiles_full_group_category_title', false );
			?>

				<div class="post-inner entry-inner entry-data">
					<?php
					if ( ! $group_cat_title ) {
						csco_get_post_meta( array( 'category' ), false, true, 'tiles_full_meta' );
					}
					?>

					<?php if ( get_the_title() ) { ?>
						<header class="entry-header">
							<?php csco_post_cat_and_title( 'h2', 'tiles_full_meta', $group_cat_title ); ?>
						</header>
					<?php } ?>

					<?php
					$post_meta_kit = array( 'views', 'shares', 'comments', 'reading_time' );

					if ( ! csco_has_post_meta( 'author', 'tiles_full_meta' ) || ! csco_has_post_meta( 'date', 'tiles_full_meta' ) ) {
						array_unshift( $post_meta_kit, 'author', 'date' );
					}

					csco_get_post_meta( $post_meta_kit, false, true, 'tiles_full_meta' );
					?>

					<?php if ( get_theme_mod( 'tiles_excerpt', true ) && get_the_excerpt() ) { ?>
						<div class="entry-excerpt">
							<?php echo esc_html( csco_str_truncate( get_the_excerpt(), 100 ) ); ?>
						</div>
					<?php } ?>

					<?php csco_post_details( 'tiles_full_meta', true, 'tiles_post_meta' ); ?>
				</div>

			<?php
			} else {
				$group_cat_title = get_theme_mod( 'tiles_simple_group_category_title', true );
				?>

				<div class="post-inner entry-inner entry-data">

					<?php if ( get_the_title() ) { ?>
						<header class="entry-header">
							<?php csco_post_cat_and_title( 'h2', 'tiles_simple_meta', $group_cat_title ); ?>
						</header>
					<?php } ?>

					<?php
					if ( 'post' === get_post_type() ) {
						$post_meta_kit = array( 'author', 'date', 'views', 'shares', 'comments', 'reading_time' );

						if ( ! $group_cat_title ) {
							array_unshift( $post_meta_kit, 'category' );
						}

						csco_get_post_meta( $post_meta_kit, false, true, 'tiles_simple_meta' );
					}
					?>

				</div>

			<?php } ?>

		</div>

	</div>

</article>
