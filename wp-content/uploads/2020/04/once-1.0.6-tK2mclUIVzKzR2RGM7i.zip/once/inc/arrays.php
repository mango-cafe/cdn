<?php
/**
 * Arrays and utility functions.
 *
 * @package Once
 */

if ( ! function_exists( 'csco_homepage_components_choices' ) ) {
	/**
	 * Returns array of all choices components for home page.
	 */
	function csco_homepage_components_choices() {
		$choices = array(
			'featured' => esc_html__( 'Featured Post', 'once' ),
			'tiles'    => esc_html__( 'Post Tiles', 'once' ),
			'carousel' => esc_html__( 'Post Carousel', 'once' ),
		);

		if ( csco_powerkit_module_enabled( 'opt_in_forms' ) ) {
			$choices['subscription'] = esc_html__( 'Subscription Form', 'once' );
		}

		return $choices;
	}
}

if ( ! function_exists( 'csco_homepage_components_default' ) ) {
	/**
	 * Returns array of all default components for home page.
	 */
	function csco_homepage_components_default() {
		$default = array();

		return $default;
	}
}

if ( ! function_exists( 'csco_allow_image_sizes' ) ) {
	/**
	 * Add the used image sizes.
	 *
	 * @param array $sizes list allow image sizes.
	 */
	function csco_allow_image_sizes( $sizes = array() ) {

		if ( ! $sizes ) {
			$sizes['original']  = array();
			$sizes['landscape'] = array();
			$sizes['square']    = array();
			$sizes['portrait']  = array();
		}

		// Get homepage components.
		$components = get_theme_mod( 'homepage_components', csco_homepage_components_default() );

		// Header mega menu.
		// ------------------------------.
		$orientation = get_theme_mod( 'header_image_orientation', 'landscape' );

		$sizes[ $orientation ] = array_merge( $sizes[ $orientation ], array(
			'csco-intermediate',
		) );

		if ( 'horizontal' === get_theme_mod( 'header_mega_menu_layout', 'horizontal' ) ) {
			$sizes[ $orientation ] = array_merge( $sizes[ $orientation ], array(
				'csco-thumbnail-small',
			) );
		}

		// Prev & Next.
		// ------------------------------.
		$orientation = get_theme_mod( 'post_prev_next_image_orientation', 'landscape' );

		if ( 'along' === get_theme_mod( 'post_prev_next', 'along' ) ) {
			$sizes[ $orientation ] = array_merge( $sizes[ $orientation ], array(
				'csco-thumbnail',
			) );
		} elseif ( 'below' === get_theme_mod( 'post_prev_next', 'along' ) ) {
			$sizes[ $orientation ] = array_merge( $sizes[ $orientation ], array(
				'csco-thumbnail',
				'csco-medium',
			) );
		}

		// Home layout.
		// ------------------------------.
		$home_layout = get_theme_mod( 'home_layout', 'masonry' );
		$orientation = get_theme_mod( 'home_image_orientation', 'original' );

		if ( 'grid' === $home_layout || 'mixed' === $home_layout ) {
			$sizes[ $orientation ] = array_merge( $sizes[ $orientation ], array(
				'csco-thumbnail',
			) );
		}

		if ( 'list' === $home_layout ) {
			$sizes[ $orientation ] = array_merge( $sizes[ $orientation ], array(
				'csco-thumbnail',
				'csco-medium',
			) );
		}

		// Archive layout.
		// ------------------------------.
		$archive_layout = get_theme_mod( 'archive_layout', 'masonry' );
		$orientation    = get_theme_mod( 'archive_image_orientation', 'original' );

		if ( 'grid' === $archive_layout || 'mixed' === $archive_layout ) {
			$sizes[ $orientation ] = array_merge( $sizes[ $orientation ], array(
				'csco-thumbnail',
			) );
		}

		if ( 'list' === $archive_layout ) {
			$sizes[ $orientation ] = array_merge( $sizes[ $orientation ], array(
				'csco-thumbnail',
				'csco-medium',
			) );
		}

		// Post tiles.
		// ------------------------------.
		if ( is_array( $components ) && in_array( 'tiles', $components, true ) ) {
			$orientation = get_theme_mod( 'tiles_image_orientation', 'square' );

			$sizes[ $orientation ] = array_merge( $sizes[ $orientation ], array(
				'csco-thumbnail',
				'csco-thumbnail-small',
				'csco-thumbnail-large',
				'csco-intermediate',
			) );
		}

		// Post carousel.
		// ------------------------------.
		if ( is_array( $components ) && in_array( 'carousel', $components, true ) ) {
			$orientation = get_theme_mod( 'carousel_image_orientation', 'square' );

			$sizes[ $orientation ] = array_merge( $sizes[ $orientation ], array(
				'csco-thumbnail',
			) );
		}

		return $sizes;
	}
	add_filter( 'csco_allow_image_sizes', 'csco_allow_image_sizes' );
}
