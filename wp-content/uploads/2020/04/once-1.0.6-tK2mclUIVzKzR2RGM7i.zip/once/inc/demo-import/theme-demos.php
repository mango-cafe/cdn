<?php
/**
 * Theme Demos
 *
 * @package Once
 */

/**
 * Theme Demos
 */
function csco_theme_demos() {
	$demos = array(
		// Theme mods imported with every demo.
		'common_mods' => array(),
		// Specific demos.
		'demos'       => array(
			'once' => array(
				'name'              => 'Once',
				'preview_image_url' => '/images/theme-demos/logo-once.png',
				'mods'              => array(
					'home_layout' => 'mixed',
					'archive_layout' => 'mixed',
					'home_image_orientation' => 'square',
					'archive_image_orientation' => 'square',
					'related_image_orientation' => 'square',
					'color_category_effect' => 'shadow',
					'color_category_effect_color' => '#8ff9f3',
					'color_primary' => '#c4a97c',
					'footer_instagram_username' => 'codesupplyco_demo',
					'header_layout' => 'with-top-bar',
					'header_follow_button_link' => '#',
					'post_load_nextpost' => true,
					'homepage_components' =>
					array(
						0 => 'featured',
						1 => 'subscription',
						2 => 'tiles',
						3 => 'carousel',
					),
				),
			),
			'edge' => array(
				'name'              => 'Edge',
				'preview_image_url' => '/images/theme-demos/logo-edge.png',
				'mods'              => array(
					'archive_group_author_date' => false,
					'archive_group_author_date_position' => 'above',
					'archive_image_orientation' => 'original',
					'archive_layout' => 'masonry',
					'archive_post_meta' =>
					array(
						0 => 'category',
						1 => 'author',
						2 => 'date',
						3 => 'views',
					),
					'carousel_background' => '#000000',
					'carousel_image_orientation' => 'landscape',
					'carousel_meta' =>
					array(
						0 => 'category',
						1 => 'author',
						2 => 'date',
						3 => 'views',
					),
					'category_subcategories' => true,
					'color_accent' => '#e8ebed',
					'color_button' => '#000000',
					'color_button_hover' => '#4d5c6a',
					'color_button_stroke' => '#4d5c6a',
					'color_button_stroke_hover' => '#4d5c6a',
					'color_category_effect' => 'shadow',
					'color_category_effect_color' => '#8ff9f3',
					'color_category_separator' => '#000000',
					'color_footer_bg' => '#000000',
					'color_large_header_bg' => '#000000',
					'color_primary' => '#4d5c6a',
					'color_title_effect' => '#64788b',
					'design_border_radius' => '0',
					'design_category_separator' => 'dot',
					'design_title_block' => 'bordered-center',
					'design_title_effect' => 'underline',
					'featured_group_category_title' => false,
					'featured_layout' => 'standard',
					'featured_meta' =>
					array(
						0 => 'category',
						1 => 'author',
						2 => 'date',
						3 => 'views',
					),
					'font_additional_menu' =>
					array(
						'font-family' => 'Karla',
						'variant' => 'regular',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'font-size' => '0.8125rem',
						'letter-spacing' => '0px',
						'text-transform' => 'uppercase',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal',
					),
					'font_base' =>
					array(
						'font-family' => 'Karla',
						'variant' => 'regular',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'font-size' => '1rem',
						'letter-spacing' => '0px',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal',
					),
					'font_entry_excerpt' =>
					array(
						'font-family' => 'Karla',
						'font-size' => '0.875rem',
						'line-height' => '1.5',
						'font-backup' => '',
						'variant' => 'regular',
						'font-weight' => 400,
						'font-style' => 'normal',
					),
					'font_footer_logo' =>
					array(
						'font-family' => 'now-alt',
						'font-size' => '1.5rem',
						'variant' => '700',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'letter-spacing' => '0.25em',
						'text-transform' => 'uppercase',
						'font-backup' => '',
						'font-weight' => 700,
						'font-style' => 'normal',
					),
					'font_headings' =>
					array(
						'font-family' => 'Karla',
						'variant' => 'regular',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'letter-spacing' => '-0.0375em',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal',
					),
					'font_large_logo' =>
					array(
						'font-family' => 'now-alt',
						'font-size' => '2rem',
						'variant' => '700',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'letter-spacing' => '0.25em',
						'text-transform' => 'uppercase',
						'font-backup' => '',
						'font-weight' => 700,
						'font-style' => 'normal',
					),
					'font_main_logo' =>
					array(
						'font-family' => 'now-alt',
						'font-size' => '1.5rem',
						'variant' => '700',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'letter-spacing' => '0.25em',
						'text-transform' => 'uppercase',
						'font-backup' => '',
						'font-weight' => 700,
						'font-style' => 'normal',
					),
					'font_menu' =>
					array(
						'font-family' => 'Karla',
						'variant' => 'regular',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'font-size' => '0.8125rem',
						'letter-spacing' => '0px',
						'text-transform' => 'uppercase',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal',
					),
					'font_post_content' =>
					array(
						'font-family' => 'Karla',
						'variant' => 'regular',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'font-size' => '0.875rem',
						'letter-spacing' => 'inherit',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal',
					),
					'font_primary' =>
					array(
						'font-family' => 'Montserrat',
						'variant' => '500',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'font-size' => '0.6875rem',
						'letter-spacing' => '0.125em',
						'text-transform' => 'uppercase',
						'font-backup' => '',
						'font-weight' => 500,
						'font-style' => 'normal',
					),
					'font_secondary' =>
					array(
						'font-family' => 'Montserrat',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'variant' => 'regular',
						'font-size' => '0.6875rem',
						'letter-spacing' => '0px',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal',
					),
					'font_secondary_headings' =>
					array(
						'font-family' => 'Montserrat',
						'variant' => '600',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'letter-spacing' => '-0.0375em',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 600,
						'font-style' => 'normal',
					),
					'font_submenu' =>
					array(
						'font-family' => 'Karla',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'variant' => 'regular',
						'font-size' => '0.875rem',
						'letter-spacing' => '0px',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal',
					),
					'font_title_block' =>
					array(
						'font-family' => 'Montserrat',
						'variant' => '700',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'font-size' => '0.6875rem',
						'letter-spacing' => '0.06875em',
						'text-transform' => 'uppercase',
						'color' => '#000000',
						'font-backup' => '',
						'font-weight' => 700,
						'font-style' => 'normal',
					),
					'footer_instagram_animation' => 'continuous',
					'footer_instagram_layout' => 'simple',
					'footer_instagram_username' => 'codesupplyco_demo',
					'footer_layout' => 'type-1',
					'footer_subscribe_name' => false,
					'footer_subscribe_title' => 'Subscribe to<br>Our Updates',
					'header_follow_button_link' => '#',
					'header_layout' => 'with-top-bar',
					'header_mega_menu_layout' => 'horizontal',
					'header_navigation_menu' => true,
					'header_shadow_submenus' => false,
					'header_top_content' => 'additional',
					'home_group_author_date' => false,
					'home_group_author_date_position' => 'below',
					'home_image_orientation' => 'original',
					'home_layout' => 'masonry',
					'home_more_button' => true,
					'home_post_meta' =>
					array(
						0 => 'category',
						1 => 'author',
						2 => 'date',
						3 => 'views',
					),
					'home_sidebar' => 'right',
					'homepage_components' =>
					array(
						0 => 'tiles',
						1 => 'carousel',
					),
					'post_header_type' => 'standard',
					'post_load_nextpost' => true,
					'post_prev_next' => 'below',
					'post_prev_next_image_orientation' => 'landscape',
					'post_prev_next_post_meta' =>
					array(
						0 => 'category',
						1 => 'author',
						2 => 'views',
						3 => 'shares',
					),
					'post_sidebar' => 'right',
					'post_subscribe_name' => true,
					'related_group_author_date' => false,
					'related_group_category_title' => false,
					'related_image_orientation' => 'portrait',
					'related_layout' => 'list',
					'related_more_button' => true,
					'related_number' => '6',
					'related_post_meta' =>
					array(
						0 => 'category',
						1 => 'author',
						2 => 'date',
						3 => 'views',
						4 => 'reading_time',
					),
					'subscription_name' => true,
					'tiles_full_meta' =>
					array(
						0 => 'category',
						1 => 'author',
						2 => 'date',
						3 => 'views',
						4 => 'shares',
					),
					'tiles_image_orientation' => 'landscape',
					'tiles_simple_meta' =>
					array(
						0 => 'category',
						1 => 'author',
						2 => 'date',
					),
					'tiles_type' => 'type-1',
				),
			),
			'off-white' => array(
				'name'              => 'Off-White',
				'preview_image_url' => '/images/theme-demos/logo-offwhite.png',
				'mods'              => array(
					'archive_group_author_date' => false,
					'archive_group_author_date_position' => 'above',
					'archive_image_orientation' => 'original',
					'archive_layout' => 'masonry',
					'archive_pagination_type' => 'load-more',
					'archive_post_meta' =>
					array(
						0 => 'category',
						1 => 'author',
						2 => 'date',
						3 => 'views',
					),
					'archive_sidebar' => 'disabled',
					'carousel_background' => '#f2f5f6',
					'carousel_image_orientation' => 'portrait',
					'category_subcategories' => true,
					'color_accent' => '#f2f5f6',
					'color_button' => '#5e6673',
					'color_button_hover' => '#b4bbc5',
					'color_category_effect' => 'shadow',
					'color_category_effect_color' => '#8ff9f3',
					'color_category_separator' => '#000000',
					'color_footer_bg' => '#f2f5f6',
					'color_primary' => '#abb7c9',
					'color_title_effect' => '#e4ebf6',
					'design_border_radius' => '0',
					'design_category_separator' => 'middle',
					'design_title_block' => 'right-border',
					'design_title_effect' => 'shadow',
					'effects_navbar_scroll' => false,
					'featured_background' => '#ffffff',
					'featured_group_category_title' => false,
					'featured_layout' => 'boxed',
					'featured_meta' =>
					array(
						0 => 'category',
						1 => 'author',
					),
					'font_additional_menu' =>
					array(
						'font-family' => 'Hind',
						'variant' => 'regular',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'font-size' => '0.75rem',
						'letter-spacing' => '0px',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal',
					),
					'font_base' =>
					array(
						'font-family' => 'Ubuntu',
						'variant' => 'regular',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'font-size' => '1rem',
						'letter-spacing' => '0px',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal',
					),
					'font_entry_excerpt' =>
					array(
						'font-family' => 'Ubuntu',
						'font-size' => '0.875rem',
						'line-height' => '1.5',
						'font-backup' => '',
						'variant' => 'regular',
						'font-weight' => 400,
						'font-style' => 'normal',
					),
					'font_footer_logo' =>
					array(
						'font-family' => 'Nunito Sans',
						'font-size' => '1.5rem',
						'variant' => '700',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'letter-spacing' => '0.25em',
						'text-transform' => 'uppercase',
						'font-backup' => '',
						'font-weight' => 700,
						'font-style' => 'normal',
					),
					'font_headings' =>
					array(
						'font-family' => 'Hind',
						'variant' => '300',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'letter-spacing' => '-0.0125em',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 300,
						'font-style' => 'normal',
					),
					'font_large_logo' =>
					array(
						'font-family' => 'now-alt',
						'font-size' => '2rem',
						'variant' => '700',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'letter-spacing' => '0.25em',
						'text-transform' => 'uppercase',
						'font-backup' => '',
						'font-weight' => 700,
						'font-style' => 'normal',
					),
					'font_main_logo' =>
					array(
						'font-family' => 'Nunito Sans',
						'font-size' => '1.5rem',
						'variant' => '700',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'letter-spacing' => '0.25em',
						'text-transform' => 'uppercase',
						'font-backup' => '',
						'font-weight' => 700,
						'font-style' => 'normal',
					),
					'font_menu' =>
					array(
						'font-family' => 'Hind',
						'variant' => 'regular',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'font-size' => '0.75rem',
						'letter-spacing' => '0px',
						'text-transform' => 'uppercase',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal',
					),
					'font_post_content' =>
					array(
						'font-family' => 'Ubuntu',
						'variant' => 'regular',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'font-size' => '0.875rem',
						'letter-spacing' => 'inherit',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal',
					),
					'font_primary' =>
					array(
						'font-family' => 'Hind',
						'variant' => 'regular',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'font-size' => '0.6875rem',
						'letter-spacing' => '0.125em',
						'text-transform' => 'uppercase',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal',
					),
					'font_secondary' =>
					array(
						'font-family' => 'Hind',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'variant' => 'regular',
						'font-size' => '0.6875rem',
						'letter-spacing' => '0px',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal',
					),
					'font_secondary_headings' =>
					array(
						'font-family' => 'Hind',
						'variant' => '500',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'letter-spacing' => '-0.0125em',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 500,
						'font-style' => 'normal',
					),
					'font_submenu' =>
					array(
						'font-family' => 'Hind',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'variant' => 'regular',
						'font-size' => '0.75rem',
						'letter-spacing' => '0px',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal',
					),
					'font_title_block' =>
					array(
						'font-family' => 'Hind',
						'variant' => 'regular',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'font-size' => '0.6875rem',
						'letter-spacing' => '0.025em',
						'text-transform' => 'uppercase',
						'color' => '#000000',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal',
					),
					'footer_instagram_button' => false,
					'footer_instagram_header' => true,
					'footer_instagram_username' => 'codesupplyco_demo',
					'footer_layout' => 'type-3',
					'footer_subscribe_name' => false,
					'footer_subscribe_title' => 'Subscribe to<br>Our Updates',
					'header_follow_button_link' => '#',
					'header_image_orientation' => 'portrait',
					'header_layout' => 'compact',
					'header_mega_menu_layout' => 'vertical',
					'header_navigation_menu' => true,
					'header_offcanvas' => true,
					'header_search_button' => false,
					'header_top_content' => 'additional',
					'home_group_author_date' => false,
					'home_group_author_date_position' => 'above',
					'home_group_category_title' => true,
					'home_image_orientation' => 'portrait',
					'home_layout' => 'grid',
					'home_more_button' => true,
					'home_pagination_type' => 'load-more',
					'home_post_meta' =>
					array(
						0 => 'category',
						1 => 'author',
						2 => 'date',
					),
					'home_sidebar' => 'disabled',
					'homepage_components' =>
					array(
						0 => 'featured',
						1 => 'carousel',
					),
					'navbar_sticky' => false,
					'post_header_type' => 'small',
					'post_load_nextpost' => false,
					'post_meta' =>
					array(
						0 => 'category',
						1 => 'date',
						2 => 'author',
						3 => 'shares',
						4 => 'views',
					),
					'post_prev_next' => 'along',
					'post_prev_next_group_category_title' => false,
					'post_prev_next_image_orientation' => 'square',
					'post_prev_next_post_meta' =>
					array(
						0 => 'category',
						1 => 'author',
						2 => 'date',
					),
					'post_sidebar' => 'disabled',
					'post_subscribe_name' => true,
					'post_tags' => false,
					'related_group_author_date' => false,
					'related_group_category_title' => false,
					'related_image_orientation' => 'portrait',
					'related_layout' => 'grid',
					'related_more_button' => true,
					'related_number' => '6',
					'related_post_meta' =>
					array(
						0 => 'category',
						1 => 'author',
						2 => 'views',
					),
					'subscription_background' => '#f2f5f6',
					'subscription_name' => true,
					'tiles_full_group_category_title' => true,
					'tiles_full_meta' =>
					array(
						0 => 'author',
						1 => 'views',
					),
					'tiles_image_orientation' => 'portrait',
					'tiles_simple_group_category_title' => false,
					'tiles_simple_meta' =>
					array(
						0 => 'category',
						1 => 'author',
						2 => 'views',
					),
					'tiles_type' => 'type-2',
					'woocommerce_header_hide_icon' => true,
				),
			),
			'wallpaper' => array(
				'name'              => 'Wallpaper',
				'preview_image_url' => '/images/theme-demos/logo-wallpaper.png',
				'mods'              => array(
					'archive_group_author_date_position' => 'above',
					'archive_layout' => 'full',
					'archive_post_meta' =>
					array(
						0 => 'category',
						1 => 'author',
						2 => 'date',
					),
					'carousel_background' => '#f7f3ed',
					'carousel_image_orientation' => 'landscape',
					'carousel_meta' =>
					array(
						0 => 'category',
						1 => 'author',
						2 => 'date',
					),
					'category_subcategories' => true,
					'color_accent' => '#f7f3ed',
					'color_button' => '#b8a797',
					'color_button_hover' => '#dbc3ad',
					'color_category_effect' => 'shadow',
					'color_category_effect_color' => '#8ff9f3',
					'color_category_separator' => '#000000',
					'color_footer_bg' => '#f7f3ed',
					'color_large_header_bg' => '#ffffff',
					'color_navbar_bg' => '#ffffff',
					'color_primary' => '#bdafa2',
					'color_title_effect' => '#d9c9b9',
					'design_border_radius' => '60px',
					'design_category_separator' => 'diamond',
					'design_title_block' => 'bordered-center',
					'design_title_effect' => 'plain',
					'featured_group_category_title' => true,
					'featured_layout' => 'large',
					'font_additional_menu' =>
					array(
						'font-family' => 'Alegreya Sans',
						'variant' => 'regular',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'font-size' => '0.875rem',
						'letter-spacing' => '0px',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal',
					),
					'font_base' =>
					array(
						'font-family' => 'Nunito Sans',
						'variant' => 'regular',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'font-size' => '1rem',
						'letter-spacing' => '0px',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal',
					),
					'font_entry_excerpt' =>
					array(
						'font-family' => 'Crimson Text',
						'font-size' => '0.875rem',
						'line-height' => '1.5',
						'font-backup' => '',
						'variant' => 'regular',
						'font-weight' => 400,
						'font-style' => 'normal',
					),
					'font_footer_logo' =>
					array(
						'font-family' => 'now-alt',
						'font-size' => '1.5rem',
						'variant' => '700',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'letter-spacing' => '0.25em',
						'text-transform' => 'uppercase',
						'font-backup' => '',
						'font-weight' => 700,
						'font-style' => 'normal',
					),
					'font_headings' =>
					array(
						'font-family' => 'Alegreya Sans',
						'variant' => 'regular',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'letter-spacing' => '-0.0125em',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal',
					),
					'font_large_logo' =>
					array(
						'font-family' => 'now-alt',
						'font-size' => '2rem',
						'variant' => '700',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'letter-spacing' => '0.25em',
						'text-transform' => 'uppercase',
						'font-backup' => '',
						'font-weight' => 700,
						'font-style' => 'normal',
					),
					'font_main_logo' =>
					array(
						'font-family' => 'now-alt',
						'font-size' => '1.5rem',
						'variant' => '700',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'letter-spacing' => '0.25em',
						'text-transform' => 'uppercase',
						'font-backup' => '',
						'font-weight' => 700,
						'font-style' => 'normal',
					),
					'font_menu' =>
					array(
						'font-family' => 'Alegreya Sans',
						'variant' => 'regular',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'font-size' => '0.75rem',
						'letter-spacing' => '0px',
						'text-transform' => 'uppercase',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal',
					),
					'font_post_content' =>
					array(
						'font-family' => 'Nunito Sans',
						'variant' => 'regular',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'font-size' => '0.875rem',
						'letter-spacing' => 'inherit',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal',
					),
					'font_primary' =>
					array(
						'font-family' => 'Nunito Sans',
						'variant' => '700',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'font-size' => '0.6875rem',
						'letter-spacing' => '0.125em',
						'text-transform' => 'uppercase',
						'font-backup' => '',
						'font-weight' => 700,
						'font-style' => 'normal',
					),
					'font_secondary' =>
					array(
						'font-family' => 'Nunito Sans',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'variant' => '700',
						'font-size' => '0.6875rem',
						'letter-spacing' => '0px',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 700,
						'font-style' => 'normal',
					),
					'font_secondary_headings' =>
					array(
						'font-family' => 'bagnard',
						'variant' => 'regular',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'letter-spacing' => '-0.0125em',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal',
					),
					'font_submenu' =>
					array(
						'font-family' => 'Alegreya Sans',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'variant' => 'regular',
						'font-size' => '0.875rem',
						'letter-spacing' => '0px',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal',
					),
					'font_title_block' =>
					array(
						'font-family' => 'Nunito',
						'variant' => 'regular',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'font-size' => '0.6875rem',
						'letter-spacing' => '0.025em',
						'text-transform' => 'uppercase',
						'color' => '#000000',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal',
					),
					'footer_instagram_layout' => 'simple',
					'footer_instagram_username' => 'codesupplyco_demo',
					'footer_layout' => 'type-2',
					'footer_subscribe_name' => false,
					'footer_subscribe_title' => 'Subscribe to<br>Our Updates',
					'header_follow_button_label' => '<i class="cs-icon cs-icon-mail"></i>Subscribe',
					'header_follow_button_link' => '#',
					'header_layout' => 'large',
					'header_mega_menu_layout' => 'vertical',
					'header_nav_height' => '100px',
					'header_search_button' => false,
					'header_social_links_scheme' => 'light',
					'home_group_author_date_position' => 'above',
					'home_image_orientation' => 'square',
					'home_layout' => 'full',
					'home_more_button' => false,
					'home_post_meta' =>
					array(
						0 => 'category',
						1 => 'author',
						2 => 'date',
					),
					'home_sidebar' => 'right',
					'home_summary' => 'excerpt',
					'homepage_components' =>
					array(
						0 => 'featured',
						1 => 'subscription',
						2 => 'tiles',
						3 => 'carousel',
					),
					'misc_sticky_sidebar_method' => 'stick-last',
					'post_header_type' => 'large',
					'post_load_nextpost' => true,
					'post_meta' =>
					array(
						0 => 'category',
						1 => 'date',
						2 => 'author',
						3 => 'shares',
						4 => 'views',
					),
					'post_prev_next_post_meta' =>
					array(
						0 => 'category',
						1 => 'author',
						2 => 'date',
					),
					'post_sidebar' => 'disabled',
					'post_subscribe_name' => true,
					'related_group_author_date' => false,
					'related_group_category_title' => true,
					'related_image_orientation' => 'landscape',
					'related_layout' => 'grid',
					'related_more_button' => false,
					'related_number' => '6',
					'related_post_meta' =>
					array(
						0 => 'category',
						1 => 'author',
						2 => 'views',
						3 => 'reading_time',
					),
					'subscription_background' => '#f7f3ed',
					'subscription_name' => true,
					'tiles_full_group_category_title' => true,
					'tiles_full_meta' =>
					array(
						0 => 'category',
						1 => 'author',
						2 => 'date',
					),
					'tiles_image_orientation' => 'landscape',
					'tiles_simple_meta' =>
					array(
						0 => 'category',
					),
					'tiles_type' => 'type-5',
				),
			),
			'untourists' => array(
				'name'              => 'Untourists',
				'preview_image_url' => '/images/theme-demos/logo-untourists.png',
				'mods'              => array(
					'archive_group_author_date_position' => 'above',
					'archive_group_category_title' => false,
					'archive_layout' => 'grid',
					'archive_more_button' => true,
					'archive_pagination_type' => 'standard',
					'archive_post_meta' =>
					array(
						0 => 'category',
						1 => 'author',
						2 => 'date',
						3 => 'views',
						4 => 'reading_time',
					),
					'archive_sidebar' => 'disabled',
					'carousel_background' => '#ebfdfd',
					'carousel_group_category_title' => false,
					'carousel_title' => 'Our Latest
				Travel Guides',
					'category_subcategories' => true,
					'color_accent' => '#ebfdfd',
					'color_button' => '#0a0a0a',
					'color_button_hover' => '#03ecec',
					'color_category_effect' => 'shadow',
					'color_category_effect_color' => '#8ff9f3',
					'color_category_separator' => '#000000',
					'color_footer_bg' => '#0a0a0a',
					'color_navbar_submenu' => '#0a0a0a',
					'color_primary' => '#0de7e7',
					'color_title_effect' => '#69fbfb',
					'design_border_radius' => '0',
					'design_category_separator' => 'square',
					'design_title_block' => 'bottom-border',
					'design_title_effect' => 'shadow',
					'featured_group_category_title' => false,
					'featured_layout' => 'small',
					'font_footer_logo' =>
					array(
						'font-family' => 'now-alt',
						'font-size' => '1.5rem',
						'variant' => '700',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'letter-spacing' => '0.25em',
						'text-transform' => 'uppercase',
						'font-backup' => '',
						'font-weight' => 700,
						'font-style' => 'normal',
					),
					'font_large_logo' =>
					array(
						'font-family' => 'now-alt',
						'font-size' => '2rem',
						'variant' => '700',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'letter-spacing' => '0.25em',
						'text-transform' => 'uppercase',
						'font-backup' => '',
						'font-weight' => 700,
						'font-style' => 'normal',
					),
					'font_main_logo' =>
					array(
						'font-family' => 'now-alt',
						'font-size' => '1.5rem',
						'variant' => '700',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'letter-spacing' => '0.25em',
						'text-transform' => 'uppercase',
						'font-backup' => '',
						'font-weight' => 700,
						'font-style' => 'normal',
					),
					'footer_instagram_layout' => 'simple',
					'footer_instagram_title' => 'Follow Us
				On Instagram',
					'footer_instagram_username' => 'codesupplyco_demo',
					'footer_layout' => 'type-3',
					'footer_subscribe_name' => false,
					'footer_subscribe_title' => 'Subscribe to<br>Our Updates',
					'header_follow_button_label' => '<i class="cs-icon cs-icon-youtube"></i>Subscribe',
					'header_follow_button_link' => '#',
					'header_layout' => 'compact',
					'header_mega_menu_layout' => 'horizontal',
					'header_offcanvas' => false,
					'header_search_button' => false,
					'home_group_author_date_position' => 'above',
					'home_group_category_title' => false,
					'home_image_orientation' => 'square',
					'home_layout' => 'grid',
					'home_more_button' => true,
					'home_pagination_type' => 'load-more',
					'home_post_meta' =>
					array(
						0 => 'category',
						1 => 'author',
						2 => 'date',
						3 => 'views',
						4 => 'reading_time',
					),
					'home_sidebar' => 'disabled',
					'homepage_components' =>
					array(
						0 => 'tiles',
						1 => 'carousel',
					),
					'page_media_preview' => 'uncropped',
					'page_sidebar' => 'disabled',
					'post_header_type' => 'small',
					'post_load_nextpost' => false,
					'post_meta' =>
					array(
						0 => 'category',
						1 => 'date',
						2 => 'author',
						3 => 'shares',
						4 => 'views',
					),
					'post_prev_next' => 'below',
					'post_prev_next_group_category_title' => false,
					'post_prev_next_image_orientation' => 'square',
					'post_prev_next_post_meta' =>
					array(
						0 => 'category',
						1 => 'author',
						2 => 'date',
						3 => 'views',
					),
					'post_sidebar' => 'disabled',
					'post_subscribe_name' => true,
					'related_group_author_date' => false,
					'related_group_category_title' => false,
					'related_image_orientation' => 'square',
					'related_layout' => 'list',
					'related_more_button' => true,
					'related_number' => '6',
					'related_post_meta' =>
					array(
						0 => 'category',
						1 => 'views',
						2 => 'reading_time',
					),
					'subscription_background' => '#ebfdfd',
					'subscription_name' => true,
					'tiles_background' => '#ffffff',
					'tiles_full_meta' =>
					array(
						0 => 'category',
						1 => 'author',
						2 => 'date',
					),
					'tiles_simple_group_category_title' => false,
					'tiles_type' => 'type-3',
					'woocommerce_header_hide_icon' => true,
				),
				'mods_typekit'      => array(
					'font_additional_menu' =>
					array(
						'font-family' => 'bureau-grot',
						'variant' => '300',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'font-size' => '0.875rem',
						'letter-spacing' => '0px',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 300,
						'font-style' => 'normal',
					),
					'font_base' =>
					array(
						'font-family' => 'canto',
						'variant' => 'regular',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'font-size' => '1rem',
						'letter-spacing' => '0px',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal',
					),
					'font_entry_excerpt' =>
					array(
						'font-family' => 'canto',
						'font-size' => '0.9375rem',
						'line-height' => '1.5',
						'font-backup' => '',
						'variant' => 'regular',
						'font-weight' => 400,
						'font-style' => 'normal',
					),
					'font_headings' =>
					array(
						'font-family' => 'bureau-grot',
						'variant' => 'regular',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'letter-spacing' => '0px',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal',
					),
					'font_menu' =>
					array(
						'font-family' => 'bureau-grot',
						'variant' => 'regular',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'font-size' => '0.8125rem',
						'letter-spacing' => '0px',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal',
					),
					'font_post_content' =>
					array(
						'font-family' => 'bureau-grot',
						'variant' => '300',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'font-size' => '0.9375rem',
						'letter-spacing' => 'inherit',
						'font-backup' => '',
						'font-weight' => 300,
						'font-style' => 'normal',
					),
					'font_primary' =>
					array(
						'font-family' => 'bureau-grot',
						'variant' => 'regular',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'font-size' => '0.6875rem',
						'letter-spacing' => '0.125em',
						'text-transform' => 'uppercase',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal',
					),
					'font_secondary' =>
					array(
						'font-family' => 'bureau-grot',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'variant' => '300',
						'font-size' => '0.6875rem',
						'letter-spacing' => '0px',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 300,
						'font-style' => 'normal',
					),
					'font_secondary_headings' =>
					array(
						'font-family' => 'bureau-grot',
						'variant' => 'regular',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'letter-spacing' => '-0.0125em',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal',
					),
					'font_submenu' =>
					array(
						'font-family' => 'bureau-grot',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'variant' => '300',
						'font-size' => '0.8125rem',
						'letter-spacing' => '0px',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 300,
						'font-style' => 'normal',
					),
					'font_title_block' =>
					array(
						'font-family' => 'bureau-grot',
						'variant' => '500',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'font-size' => '0.6875rem',
						'letter-spacing' => '0.025em',
						'text-transform' => 'uppercase',
						'color' => '#000000',
						'font-backup' => '',
						'font-weight' => 500,
						'font-style' => 'normal',
					),
				),
			),
			'brunch' => array(
				'name'              => 'Brunch',
				'preview_image_url' => '/images/theme-demos/logo-brunch.png',
				'mods'              => array(
					'archive_group_author_date_position' => 'above',
					'archive_image_orientation' => 'portrait',
					'archive_layout' => 'list',
					'archive_post_meta' =>
					array(
						0 => 'category',
						1 => 'author',
						2 => 'date',
						3 => 'views',
						4 => 'reading_time',
					),
					'category_subcategories' => true,
					'color_accent' => '#f7f7f2',
					'color_button_hover' => '#ccccac',
					'color_category_effect' => 'shadow',
					'color_category_effect_color' => '#8ff9f3',
					'color_category_separator' => '#000000',
					'color_footer_bg' => '#f7f7f2',
					'color_large_header_bg' => '#f7f7f2',
					'color_primary' => '#ccccac',
					'color_title_effect' => '#ccccac',
					'design_border_radius' => '0',
					'design_category_separator' => 'square',
					'design_title_block' => 'bordered-right',
					'design_title_effect' => 'underline',
					'effects_navbar_scroll' => false,
					'featured_group_category_title' => true,
					'featured_layout' => 'small',
					'font_footer_logo' =>
					array(
						'font-family' => 'now-alt',
						'font-size' => '1.5rem',
						'variant' => '700',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'letter-spacing' => '0.25em',
						'text-transform' => 'uppercase',
						'font-backup' => '',
						'font-weight' => 700,
						'font-style' => 'normal',
					),
					'font_large_logo' =>
					array(
						'font-family' => 'now-alt',
						'font-size' => '2rem',
						'variant' => '700',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'letter-spacing' => '0.25em',
						'text-transform' => 'uppercase',
						'font-backup' => '',
						'font-weight' => 700,
						'font-style' => 'normal',
					),
					'font_main_logo' =>
					array(
						'font-family' => 'now-alt',
						'font-size' => '1.5rem',
						'variant' => '700',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'letter-spacing' => '0.25em',
						'text-transform' => 'uppercase',
						'font-backup' => '',
						'font-weight' => 700,
						'font-style' => 'normal',
					),
					'footer_instagram_animation' => 'stepwise',
					'footer_instagram_header' => true,
					'footer_instagram_username' => 'codesupplyco_demo',
					'footer_layout' => 'type-2',
					'footer_social_links_scheme' => 'light',
					'footer_subscribe_name' => false,
					'footer_subscribe_title' => 'Subscribe to<br>Our Updates',
					'header_follow_button_link' => '#',
					'header_layout' => 'large',
					'header_mega_menu_layout' => 'horizontal',
					'header_nav_height' => '120px',
					'header_navigation_menu' => true,
					'header_social_links_scheme' => 'light',
					'header_tagline' => false,
					'home_group_author_date_position' => 'above',
					'home_image_orientation' => 'portrait',
					'home_layout' => 'list',
					'home_more_button' => false,
					'home_post_meta' =>
					array(
						0 => 'category',
						1 => 'author',
						2 => 'date',
						3 => 'views',
						4 => 'reading_time',
					),
					'home_sidebar' => 'right',
					'homepage_components' =>
					array(
						0 => 'tiles',
						1 => 'subscription',
					),
					'misc_sticky_sidebar_method' => 'stick-last',
					'navbar_sticky' => false,
					'page_header_type' => 'large',
					'post_comments_simple' => true,
					'post_header_type' => 'large',
					'post_load_nextpost' => false,
					'post_meta' =>
					array(
						0 => 'category',
						1 => 'date',
						2 => 'author',
						3 => 'shares',
						4 => 'views',
					),
					'post_prev_next_image_orientation' => 'portrait',
					'post_prev_next_post_meta' =>
					array(
						0 => 'category',
						1 => 'author',
						2 => 'date',
					),
					'post_sidebar' => 'right',
					'post_subscribe_name' => true,
					'post_subscribe_title' => 'Subscribe to
				Our Daily Healthy Branches',
					'related_group_author_date' => true,
					'related_group_category_title' => true,
					'related_image_orientation' => 'portrait',
					'related_layout' => 'list',
					'related_more_button' => false,
					'related_number' => '6',
					'related_post_meta' =>
					array(
						0 => 'category',
						1 => 'author',
						2 => 'date',
						3 => 'views',
						4 => 'reading_time',
					),
					'subscription_background' => '#f7f7f2',
					'subscription_name' => true,
					'subscription_title' => 'Subscribe to
				Daily Healthy Brunches',
					'tiles_full_meta' =>
					array(
						0 => 'category',
						1 => 'author',
						2 => 'date',
						3 => 'views',
						4 => 'shares',
					),
					'tiles_image_orientation' => 'square',
					'tiles_simple_meta' =>
					array(
						0 => 'category',
						1 => 'author',
						2 => 'shares',
						3 => 'views',
					),
					'tiles_type' => 'type-5',
				),
				'mods_typekit'      => array(
					'font_additional_menu' =>
					array(
						'font-family' => 'acumin-pro',
						'variant' => '500',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'font-size' => '0.875rem',
						'letter-spacing' => '0px',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 500,
						'font-style' => 'normal',
					),
					'font_base' =>
					array(
						'font-family' => 'acumin-pro',
						'variant' => 'regular',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'font-size' => '1rem',
						'letter-spacing' => '0px',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal',
					),
					'font_entry_excerpt' =>
					array(
						'font-family' => 'acumin-pro',
						'font-size' => '0.875rem',
						'line-height' => '1.5',
						'font-backup' => '',
						'variant' => 'regular',
						'font-weight' => 400,
						'font-style' => 'normal',
					),
					'font_headings' =>
					array(
						'font-family' => 'cormorant-garamond',
						'variant' => 'regular',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'letter-spacing' => '0px',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal',
					),
					'font_menu' =>
					array(
						'font-family' => 'acumin-pro',
						'variant' => '500',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'font-size' => '0.875rem',
						'letter-spacing' => '0px',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 500,
						'font-style' => 'normal',
					),
					'font_post_content' =>
					array(
						'font-family' => 'acumin-pro',
						'variant' => 'regular',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'font-size' => '0.875rem',
						'letter-spacing' => 'inherit',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal',
					),
					'font_primary' =>
					array(
						'font-family' => 'acumin-pro',
						'variant' => '600',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'font-size' => '0.6875rem',
						'letter-spacing' => '0.125em',
						'text-transform' => 'uppercase',
						'font-backup' => '',
						'font-weight' => 600,
						'font-style' => 'normal',
					),
					'font_secondary' =>
					array(
						'font-family' => 'acumin-pro',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'variant' => '500',
						'font-size' => '0.6875rem',
						'letter-spacing' => '0px',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 500,
						'font-style' => 'normal',
					),
					'font_secondary_headings' =>
					array(
						'font-family' => 'acumin-pro',
						'variant' => '600',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'letter-spacing' => '-0.0125em',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 600,
						'font-style' => 'normal',
					),
					'font_submenu' =>
					array(
						'font-family' => 'acumin-pro',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'variant' => 'regular',
						'font-size' => '0.875rem',
						'letter-spacing' => '0px',
						'text-transform' => 'none',
						'font-backup' => '',
						'font-weight' => 400,
						'font-style' => 'normal',
					),
					'font_title_block' =>
					array(
						'font-family' => 'acumin-pro',
						'variant' => '600',
						'subsets' =>
						array(
							0 => 'latin',
						),
						'font-size' => '0.6875rem',
						'letter-spacing' => '0.025em',
						'text-transform' => 'uppercase',
						'color' => '#000000',
						'font-backup' => '',
						'font-weight' => 600,
						'font-style' => 'normal',
					),
				),
			),
		),
	);
	return $demos;
}
add_filter( 'csco_theme_demos', 'csco_theme_demos' );
