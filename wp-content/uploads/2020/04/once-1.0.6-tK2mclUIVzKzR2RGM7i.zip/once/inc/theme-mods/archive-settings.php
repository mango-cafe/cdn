<?php
/**
 * Archive Settings
 *
 * @package Once
 */

CSCO_Kirki::add_section(
	'archive_settings', array(
		'title'    => esc_html__( 'Archive Settings', 'once' ),
		'priority' => 50,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'radio',
		'settings' => 'archive_layout',
		'label'    => esc_html__( 'Layout', 'once' ),
		'section'  => 'archive_settings',
		'default'  => 'masonry',
		'priority' => 10,
		'choices'  => array(
			'full'    => esc_html__( 'Full Post Layout', 'once' ),
			'list'    => esc_html__( 'List Layout', 'once' ),
			'grid'    => esc_html__( 'Grid Layout', 'once' ),
			'masonry' => esc_html__( 'Masonry Layout', 'once' ),
			'mixed'   => esc_html__( 'Mixed Layout', 'once' ),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'radio',
		'settings' => 'archive_sidebar',
		'label'    => esc_html__( 'Sidebar', 'once' ),
		'section'  => 'archive_settings',
		'default'  => 'right',
		'priority' => 10,
		'choices'  => array(
			'right'    => esc_html__( 'Right Sidebar', 'once' ),
			'left'     => esc_html__( 'Left Sidebar', 'once' ),
			'disabled' => esc_html__( 'No Sidebar', 'once' ),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'radio',
		'settings'        => 'archive_image_orientation',
		'label'           => esc_html__( 'Image Orientation', 'once' ),
		'section'         => 'archive_settings',
		'default'         => 'original',
		'priority'        => 10,
		'choices'         => array(
			'original'  => esc_html__( 'Original', 'once' ),
			'landscape' => esc_html__( 'Landscape', 'once' ),
			'square'    => esc_html__( 'Square', 'once' ),
			'portrait'  => esc_html__( 'Portrait', 'once' ),
		),
		'active_callback' => array(
			array(
				array(
					'setting'  => 'archive_layout',
					'operator' => '==',
					'value'    => 'list',
				),
				array(
					'setting'  => 'archive_layout',
					'operator' => '==',
					'value'    => 'grid',
				),
				array(
					'setting'  => 'archive_layout',
					'operator' => '==',
					'value'    => 'masonry',
				),
				array(
					'setting'  => 'archive_layout',
					'operator' => '==',
					'value'    => 'mixed',
				),
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'multicheck',
		'settings' => 'archive_post_meta',
		'label'    => esc_html__( 'Post Meta', 'once' ),
		'section'  => 'archive_settings',
		'default'  => array( 'category', 'author', 'date', 'views', 'reading_time' ),
		'priority' => 10,
		'choices'  => apply_filters( 'csco_post_meta_choices', array(
			'category'     => esc_html__( 'Category', 'once' ),
			'author'       => esc_html__( 'Author', 'once' ),
			'date'         => esc_html__( 'Date', 'once' ),
			'views'        => esc_html__( 'Views', 'once' ),
			'shares'       => esc_html__( 'Shares', 'once' ),
			'comments'     => esc_html__( 'Comments', 'once' ),
			'reading_time' => esc_html__( 'Reading Time', 'once' ),
		) ),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'checkbox',
		'settings'        => 'archive_group_category_title',
		'label'           => esc_html__( 'Group category and post title', 'once' ),
		'section'         => 'archive_settings',
		'default'         => true,
		'priority'        => 10,
		'active_callback' => array(
			array(
				array(
					'setting'  => 'archive_layout',
					'operator' => '==',
					'value'    => 'list',
				),
				array(
					'setting'  => 'archive_layout',
					'operator' => '==',
					'value'    => 'grid',
				),
				array(
					'setting'  => 'archive_layout',
					'operator' => '==',
					'value'    => 'masonry',
				),
				array(
					'setting'  => 'archive_layout',
					'operator' => '==',
					'value'    => 'mixed',
				),
			),
			array(
				'setting'  => 'archive_post_meta',
				'operator' => 'in',
				'value'    => 'category',
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'checkbox',
		'settings'        => 'archive_group_author_date',
		'label'           => esc_html__( 'Group post author and date', 'once' ),
		'section'         => 'archive_settings',
		'default'         => true,
		'priority'        => 10,
		'active_callback' => array(
			array(
				array(
					'setting'  => 'archive_layout',
					'operator' => '==',
					'value'    => 'list',
				),
				array(
					'setting'  => 'archive_layout',
					'operator' => '==',
					'value'    => 'grid',
				),
				array(
					'setting'  => 'archive_layout',
					'operator' => '==',
					'value'    => 'masonry',
				),
				array(
					'setting'  => 'archive_layout',
					'operator' => '==',
					'value'    => 'mixed',
				),
			),
			array(
				'setting'  => 'archive_post_meta',
				'operator' => 'in',
				'value'    => 'author',
			),
			array(
				'setting'  => 'archive_post_meta',
				'operator' => 'in',
				'value'    => 'date',
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'radio',
		'settings'        => 'archive_group_author_date_position',
		'label'           => esc_html__( 'Group Post Author and Date Position', 'once' ),
		'section'         => 'archive_settings',
		'default'         => 'above',
		'priority'        => 10,
		'choices'         => array(
			'above' => esc_html__( 'Above post title', 'once' ),
			'below' => esc_html__( 'Below post summary', 'once' ),
		),
		'active_callback' => array(
			array(
				array(
					'setting'  => 'archive_layout',
					'operator' => '==',
					'value'    => 'list',
				),
				array(
					'setting'  => 'archive_layout',
					'operator' => '==',
					'value'    => 'grid',
				),
				array(
					'setting'  => 'archive_layout',
					'operator' => '==',
					'value'    => 'masonry',
				),
				array(
					'setting'  => 'archive_layout',
					'operator' => '==',
					'value'    => 'mixed',
				),
			),
			array(
				'setting'  => 'archive_post_meta',
				'operator' => 'in',
				'value'    => 'author',
			),
			array(
				'setting'  => 'archive_post_meta',
				'operator' => 'in',
				'value'    => 'date',
			),
			array(
				'setting'  => 'archive_group_author_date',
				'operator' => '==',
				'value'    => true,
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'radio',
		'settings'        => 'archive_media_preview',
		'label'           => esc_html__( 'Post Preview Image Size', 'once' ),
		'section'         => 'archive_settings',
		'default'         => 'cropped',
		'priority'        => 10,
		'choices'         => array(
			'cropped'   => esc_html__( 'Display Cropped Image', 'once' ),
			'uncropped' => esc_html__( 'Display Preview in Original Ratio', 'once' ),
		),
		'active_callback' => array(
			array(
				'setting'  => 'archive_layout',
				'operator' => '==',
				'value'    => 'full',
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'radio',
		'settings'        => 'archive_summary',
		'label'           => esc_html__( 'Full Post Summary', 'once' ),
		'section'         => 'archive_settings',
		'default'         => 'excerpt',
		'priority'        => 10,
		'choices'         => array(
			'excerpt' => esc_html__( 'Use Excerpts', 'once' ),
			'content' => esc_html__( 'Use Read More Tag', 'once' ),
		),
		'active_callback' => array(
			array(
				'setting'  => 'archive_layout',
				'operator' => '==',
				'value'    => 'full',
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'checkbox',
		'settings' => 'archive_excerpt',
		'label'    => esc_html__( 'Display excerpts', 'once' ),
		'section'  => 'archive_settings',
		'default'  => true,
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'checkbox',
		'settings' => 'archive_more_button',
		'label'    => esc_html__( 'Display read more button', 'once' ),
		'section'  => 'archive_settings',
		'default'  => false,
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'radio',
		'settings' => 'archive_pagination_type',
		'label'    => esc_html__( 'Pagination', 'once' ),
		'section'  => 'archive_settings',
		'default'  => 'load-more',
		'priority' => 10,
		'choices'  => array(
			'standard'  => esc_html__( 'Standard', 'once' ),
			'load-more' => esc_html__( 'Load More Button', 'once' ),
			'infinite'  => esc_html__( 'Infinite Load', 'once' ),
		),
	)
);
