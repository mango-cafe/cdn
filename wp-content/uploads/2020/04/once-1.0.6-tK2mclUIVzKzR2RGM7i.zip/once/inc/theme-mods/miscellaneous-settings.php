<?php
/**
 * Miscellaneous Settings
 *
 * @package Once
 */

CSCO_Kirki::add_section(
	'miscellaneous', array(
		'title'    => esc_html__( 'Miscellaneous Settings', 'once' ),
		'priority' => 60,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'checkbox',
		'settings' => 'misc_published_date',
		'label'    => esc_html__( 'Display published date instead of modified date', 'once' ),
		'section'  => 'miscellaneous',
		'default'  => true,
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'checkbox',
		'settings' => 'misc_separate_link_cat_title',
		'label'    => esc_html__( 'Enable separate links for categories and post titles', 'once' ),
		'section'  => 'miscellaneous',
		'default'  => false,
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'text',
		'settings' => 'misc_search_placeholder',
		'label'    => esc_html__( 'Search Form Placeholder', 'once' ),
		'section'  => 'miscellaneous',
		'default'  => esc_html__( 'Enter keyword', 'once' ),
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'text',
		'settings' => 'misc_label_readmore',
		'label'    => esc_html__( '"Read More" Button Label', 'once' ),
		'section'  => 'miscellaneous',
		'default'  => esc_html__( 'Read More', 'once' ),
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'radio',
		'settings' => 'misc_classic_gallery_alignment',
		'label'    => esc_html__( 'Alignment of Galleries in Classic Block', 'once' ),
		'section'  => 'miscellaneous',
		'default'  => 'default',
		'priority' => 10,
		'choices'  => array(
			'default' => esc_html__( 'Default', 'once' ),
			'wide'    => esc_html__( 'Wide', 'once' ),
			'large'   => esc_html__( 'Large', 'once' ),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'checkbox',
		'settings' => 'misc_sticky_sidebar',
		'label'    => esc_html__( 'Sticky Sidebar', 'once' ),
		'section'  => 'miscellaneous',
		'default'  => true,
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'radio',
		'settings'        => 'misc_sticky_sidebar_method',
		'label'           => esc_html__( 'Sticky Method', 'once' ),
		'section'         => 'miscellaneous',
		'default'         => 'stick-to-top',
		'priority'        => 10,
		'choices'         => array(
			'stick-to-top'    => esc_html__( 'Sidebar top edge', 'once' ),
			'stick-to-bottom' => esc_html__( 'Sidebar bottom edge', 'once' ),
			'stick-last'      => esc_html__( 'Last widget top edge', 'once' ),
		),
		'active_callback' => array(
			array(
				'setting'  => 'misc_sticky_sidebar',
				'operator' => '==',
				'value'    => true,
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'        => 'radio',
		'settings'    => 'image_sizes_registration_method',
		'label'       => esc_html__( 'Image sizes registration', 'once' ),
		'description' => esc_html__( 'Registering all image sizes will result in more disk space used and slightly slower image upload, but you won’t have to regenerate thumbnails every time you change theme settings. Smart mode will register only those sizes and ratios that are currently selected in theme options. It uses less disk space and provides faster image upload, but requires to regenerate thumbnails every time you change theme settings.', 'once' ),
		'section'     => 'miscellaneous',
		'default'     => 'all',
		'priority'    => 10,
		'choices'     => array(
			'all'   => esc_html__( 'All sizes', 'once' ),
			'smart' => esc_html__( 'Smart mode', 'once' ),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'        => 'radio',
		'settings'    => 'webfonts_load_method',
		'label'       => esc_html__( 'Webfonts Load Method', 'once' ),
		'description' => esc_html__( 'Please', 'once' ) . ' <a href="' . add_query_arg( array( 'action' => 'kirki-reset-cache' ), get_site_url() ) . '" target="_blank">' . esc_html__( 'reset font cache', 'once' ) . '</a> ' . esc_html__( 'after saving.', 'once' ),
		'section'     => 'miscellaneous',
		'default'     => 'async',
		'priority'    => 10,
		'choices'     => array(
			'async' => esc_html__( 'Asynchronous', 'once' ),
			'link'  => esc_html__( 'Render-Blocking', 'once' ),
		),
	)
);
