<?php
/**
 * Post Settings
 *
 * @package Once
 */

CSCO_Kirki::add_section(
	'post_settings', array(
		'title'    => esc_html__( 'Post Settings', 'once' ),
		'priority' => 50,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'collapsible',
		'settings' => 'post_collapsible_general',
		'label'    => esc_html__( 'General', 'once' ),
		'section'  => 'post_settings',
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'radio',
		'settings' => 'post_sidebar',
		'label'    => esc_html__( 'Default Sidebar', 'once' ),
		'section'  => 'post_settings',
		'default'  => 'disabled',
		'priority' => 10,
		'choices'  => array(
			'right'    => esc_html__( 'Right Sidebar', 'once' ),
			'left'     => esc_html__( 'Left Sidebar', 'once' ),
			'disabled' => esc_html__( 'No Sidebar', 'once' ),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'multicheck',
		'settings' => 'post_meta',
		'label'    => esc_html__( 'Post Meta', 'once' ),
		'section'  => 'post_settings',
		'default'  => array( 'category', 'date', 'author', 'shares', 'views', 'reading_time' ),
		'priority' => 10,
		'choices'  => apply_filters( 'csco_post_meta_choices', array(
			'category'     => esc_html__( 'Category', 'once' ),
			'date'         => esc_html__( 'Date', 'once' ),
			'author'       => esc_html__( 'Author', 'once' ),
			'shares'       => esc_html__( 'Shares', 'once' ),
			'views'        => esc_html__( 'Views', 'once' ),
			'comments'     => esc_html__( 'Comments', 'once' ),
			'reading_time' => esc_html__( 'Reading Time', 'once' ),
		) ),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'radio',
		'settings' => 'post_header_type',
		'label'    => esc_html__( 'Default Page Header Type', 'once' ),
		'section'  => 'post_settings',
		'default'  => 'standard',
		'priority' => 10,
		'choices'  => array(
			'standard' => esc_html__( 'Standard', 'once' ),
			'small'    => esc_html__( 'Small', 'once' ),
			'large'    => esc_html__( 'Large', 'once' ),
			'title'    => esc_html__( 'Page Title Only', 'once' ),
			'none'     => esc_html__( 'None', 'once' ),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'radio',
		'settings'        => 'post_media_preview',
		'label'           => esc_html__( 'Standard Page Header Preview', 'once' ),
		'section'         => 'post_settings',
		'default'         => 'cropped',
		'priority'        => 10,
		'choices'         => array(
			'cropped'   => esc_html__( 'Display Cropped Image', 'once' ),
			'uncropped' => esc_html__( 'Display Preview in Original Ratio', 'once' ),
		),
		'active_callback' => array(
			array(
				'setting'  => 'post_header_type',
				'operator' => '==',
				'value'    => 'standard',
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'checkbox',
		'settings' => 'post_tags',
		'label'    => esc_html__( 'Display tags', 'once' ),
		'section'  => 'post_settings',
		'default'  => true,
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'checkbox',
		'settings' => 'post_excerpt',
		'label'    => esc_html__( 'Display excerpts', 'once' ),
		'section'  => 'post_settings',
		'default'  => true,
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'checkbox',
		'settings' => 'post_comments_simple',
		'label'    => esc_html__( 'Display comments without the View Comments button', 'once' ),
		'section'  => 'post_settings',
		'default'  => false,
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'collapsible',
		'settings' => 'post_collapsible_load_prev_next',
		'label'    => esc_html__( 'Prev Next Links', 'once' ),
		'section'  => 'post_settings',
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'radio',
		'settings' => 'post_prev_next',
		'label'    => esc_html__( 'Layout', 'once' ),
		'section'  => 'post_settings',
		'default'  => 'along',
		'priority' => 10,
		'choices'  => array(
			'disabled' => esc_html__( 'Disabled', 'once' ),
			'along'    => esc_html__( 'Along the edges', 'once' ),
			'below'    => esc_html__( 'Below post content', 'once' ),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'radio',
		'settings'        => 'post_prev_next_image_orientation',
		'label'           => esc_html__( 'Image Orientation', 'once' ),
		'section'         => 'post_settings',
		'default'         => 'landscape',
		'priority'        => 10,
		'choices'         => array(
			'original'  => esc_html__( 'Original', 'once' ),
			'landscape' => esc_html__( 'Landscape', 'once' ),
			'square'    => esc_html__( 'Square', 'once' ),
			'portrait'  => esc_html__( 'Portrait', 'once' ),
		),
		'active_callback' => array(
			array(
				'setting'  => 'post_prev_next',
				'operator' => '!=',
				'value'    => 'disabled',
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'multicheck',
		'settings'        => 'post_prev_next_post_meta',
		'label'           => esc_html__( 'Post Meta', 'once' ),
		'section'         => 'post_settings',
		'default'         => array( 'category', 'author', 'date' ),
		'priority'        => 10,
		'choices'         => apply_filters( 'csco_post_meta_choices', array(
			'category'     => esc_html__( 'Category', 'once' ),
			'author'       => esc_html__( 'Author', 'once' ),
			'date'         => esc_html__( 'Date', 'once' ),
			'views'        => esc_html__( 'Views', 'once' ),
			'shares'       => esc_html__( 'Shares', 'once' ),
			'comments'     => esc_html__( 'Comments', 'once' ),
			'reading_time' => esc_html__( 'Reading Time', 'once' ),
		) ),
		'active_callback' => array(
			array(
				'setting'  => 'post_prev_next',
				'operator' => '!=',
				'value'    => 'disabled',
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'checkbox',
		'settings'        => 'post_prev_next_group_category_title',
		'label'           => esc_html__( 'Group category and post title', 'once' ),
		'section'         => 'post_settings',
		'default'         => true,
		'priority'        => 10,
		'active_callback' => array(
			array(
				'setting'  => 'post_prev_next',
				'operator' => '!=',
				'value'    => 'disabled',
			),
			array(
				'setting'  => 'post_prev_next_post_meta',
				'operator' => 'in',
				'value'    => 'category',
			),
		),
	)
);

if ( csco_powerkit_module_enabled( 'opt_in_forms' ) ) {
	CSCO_Kirki::add_field(
		'csco_theme_mod', array(
			'type'     => 'collapsible',
			'settings' => 'post_collapsible_subscribe',
			'label'    => esc_html__( 'Subscription Form', 'once' ),
			'section'  => 'post_settings',
			'priority' => 10,
		)
	);

	CSCO_Kirki::add_field(
		'csco_theme_mod', array(
			'type'     => 'checkbox',
			'settings' => 'post_subscribe',
			'label'    => esc_html__( 'Display subscribe section', 'once' ),
			'section'  => 'post_settings',
			'default'  => false,
			'priority' => 10,
		)
	);

	CSCO_Kirki::add_field(
		'csco_theme_mod', array(
			'type'            => 'checkbox',
			'settings'        => 'post_subscribe_name',
			'label'           => esc_html__( 'Display first name field', 'once' ),
			'section'         => 'post_settings',
			'default'         => false,
			'priority'        => 10,
			'active_callback' => array(
				array(
					'setting'  => 'post_subscribe',
					'operator' => '==',
					'value'    => true,
				),
			),
		)
	);

	CSCO_Kirki::add_field(
		'csco_theme_mod', array(
			'type'              => 'textarea',
			'settings'          => 'post_subscribe_title',
			'label'             => esc_html__( 'Title', 'once' ),
			'section'           => 'post_settings',
			'default'           => esc_html__( 'Subscribe to Get Our', 'once' ) . "\n" . esc_html__( 'Newsletter', 'once' ),
			'description'       => esc_html__( 'Insert a line break to style the second line differently.', 'once' ),
			'priority'          => 10,
			'sanitize_callback' => 'wp_kses_post',
			'active_callback'   => array(
				array(
					'setting'  => 'post_subscribe',
					'operator' => '==',
					'value'    => true,
				),
			),
		)
	);

	CSCO_Kirki::add_field(
		'csco_theme_mod', array(
			'type'              => 'text',
			'settings'          => 'post_subscribe_text',
			'label'             => esc_html__( 'Text', 'once' ),
			'section'           => 'post_settings',
			'default'           => esc_html__( 'Get notified of the best deals on our WordPress themes.', 'once' ),
			'priority'          => 10,
			'sanitize_callback' => 'wp_kses_post',
			'active_callback'   => array(
				array(
					'setting'  => 'post_subscribe',
					'operator' => '==',
					'value'    => true,
				),
			),
		)
	);
}

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'collapsible',
		'settings' => 'post_collapsible_related',
		'label'    => esc_html__( 'Related Post', 'once' ),
		'section'  => 'post_settings',
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'checkbox',
		'settings' => 'related',
		'label'    => esc_html__( 'Display related section', 'once' ),
		'section'  => 'post_settings',
		'default'  => true,
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'radio',
		'settings'        => 'related_layout',
		'label'           => esc_html__( 'Related Post Layout', 'once' ),
		'section'         => 'post_settings',
		'default'         => 'grid',
		'priority'        => 10,
		'choices'         => array(
			'list' => esc_html__( 'List', 'once' ),
			'grid' => esc_html__( 'Grid', 'once' ),
		),
		'active_callback' => array(
			array(
				'setting'  => 'related',
				'operator' => '==',
				'value'    => true,
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'number',
		'settings'        => 'related_number',
		'label'           => esc_html__( 'Maximum Number of Related Posts', 'once' ),
		'section'         => 'post_settings',
		'default'         => 6,
		'priority'        => 10,
		'active_callback' => array(
			array(
				'setting'  => 'related',
				'operator' => '==',
				'value'    => true,
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'radio',
		'settings'        => 'related_image_orientation',
		'label'           => esc_html__( 'Image Orientation', 'once' ),
		'section'         => 'post_settings',
		'default'         => 'original',
		'priority'        => 10,
		'choices'         => array(
			'original'  => esc_html__( 'Original', 'once' ),
			'landscape' => esc_html__( 'Landscape', 'once' ),
			'square'    => esc_html__( 'Square', 'once' ),
			'portrait'  => esc_html__( 'Portrait', 'once' ),
		),
		'active_callback' => array(
			array(
				'setting'  => 'related',
				'operator' => '==',
				'value'    => true,
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'multicheck',
		'settings'        => 'related_post_meta',
		'label'           => esc_attr__( 'Post Meta', 'once' ),
		'section'         => 'post_settings',
		'default'         => array( 'category', 'views', 'reading_time' ),
		'priority'        => 10,
		'choices'         => apply_filters( 'csco_post_meta_choices', array(
			'category'     => esc_html__( 'Category', 'once' ),
			'author'       => esc_html__( 'Author', 'once' ),
			'date'         => esc_html__( 'Date', 'once' ),
			'shares'       => esc_html__( 'Shares', 'once' ),
			'views'        => esc_html__( 'Views', 'once' ),
			'comments'     => esc_html__( 'Comments', 'once' ),
			'reading_time' => esc_html__( 'Reading Time', 'once' ),
		) ),
		'active_callback' => array(
			array(
				'setting'  => 'related',
				'operator' => '==',
				'value'    => true,
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'checkbox',
		'settings'        => 'related_group_category_title',
		'label'           => esc_html__( 'Group category and post title', 'once' ),
		'section'         => 'post_settings',
		'default'         => false,
		'priority'        => 10,
		'active_callback' => array(
			array(
				'setting'  => 'related',
				'operator' => '==',
				'value'    => true,
			),
			array(
				'setting'  => 'tiles_simple_meta',
				'operator' => 'in',
				'value'    => 'category',
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'checkbox',
		'settings'        => 'related_group_author_date',
		'label'           => esc_html__( 'Group post author and date', 'once' ),
		'section'         => 'post_settings',
		'default'         => false,
		'priority'        => 10,
		'active_callback' => array(
			array(
				'setting'  => 'related',
				'operator' => '==',
				'value'    => true,
			),
			array(
				'setting'  => 'related_post_meta',
				'operator' => 'in',
				'value'    => 'author',
			),
			array(
				'setting'  => 'related_post_meta',
				'operator' => 'in',
				'value'    => 'date',
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'radio',
		'settings'        => 'related_group_author_date_position',
		'label'           => esc_html__( 'Group Post Author and Date Position', 'once' ),
		'section'         => 'post_settings',
		'default'         => 'above',
		'priority'        => 10,
		'choices'         => array(
			'above' => esc_html__( 'Above post title', 'once' ),
			'below' => esc_html__( 'Below post summary', 'once' ),
		),
		'active_callback' => array(
			array(
				'setting'  => 'related',
				'operator' => '==',
				'value'    => true,
			),
			array(
				'setting'  => 'related_post_meta',
				'operator' => 'in',
				'value'    => 'author',
			),
			array(
				'setting'  => 'related_post_meta',
				'operator' => 'in',
				'value'    => 'date',
			),
			array(
				'setting'  => 'related_group_author_date',
				'operator' => '==',
				'value'    => true,
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'checkbox',
		'settings'        => 'related_excerpt',
		'label'           => esc_html__( 'Display excerpts', 'once' ),
		'section'         => 'post_settings',
		'default'         => true,
		'priority'        => 10,
		'active_callback' => array(
			array(
				'setting'  => 'related',
				'operator' => '==',
				'value'    => true,
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'checkbox',
		'settings'        => 'related_more_button',
		'label'           => esc_html__( 'Display read more button', 'once' ),
		'section'         => 'post_settings',
		'default'         => false,
		'priority'        => 10,
		'active_callback' => array(
			array(
				'setting'  => 'related',
				'operator' => '==',
				'value'    => true,
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'text',
		'settings'        => 'related_time_frame',
		'label'           => esc_html__( 'Time Frame', 'once' ),
		'description'     => esc_html__( 'Add period of posts in English. For example: &laquo;2 months&raquo;, &laquo;14 days&raquo; or even &laquo;1 year&raquo;', 'once' ),
		'section'         => 'post_settings',
		'default'         => '',
		'priority'        => 10,
		'active_callback' => array(
			array(
				'setting'  => 'related',
				'operator' => '==',
				'value'    => true,
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'collapsible',
		'settings' => 'post_collapsible_load_nextpost',
		'label'    => esc_html__( 'Auto Load Next Post', 'once' ),
		'section'  => 'post_settings',
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'checkbox',
		'settings' => 'post_load_nextpost',
		'label'    => esc_html__( 'Enable the Auto Load Next Post feature', 'once' ),
		'section'  => 'post_settings',
		'default'  => false,
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'checkbox',
		'settings'        => 'post_load_nextpost_same_category',
		'label'           => esc_html__( 'Auto load posts from the same category only', 'once' ),
		'section'         => 'post_settings',
		'default'         => false,
		'priority'        => 10,
		'active_callback' => array(
			array(
				'setting'  => 'post_load_nextpost',
				'operator' => '==',
				'value'    => true,
			),
		),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'checkbox',
		'settings'        => 'post_load_nextpost_reverse',
		'label'           => esc_html__( 'Auto load previous posts instead of next ones', 'once' ),
		'section'         => 'post_settings',
		'default'         => false,
		'priority'        => 10,
		'active_callback' => array(
			array(
				'setting'  => 'post_load_nextpost',
				'operator' => '==',
				'value'    => true,
			),
		),
	)
);
