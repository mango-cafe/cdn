<?php
/**
 * Typography
 *
 * @package Once
 */

CSCO_Kirki::add_panel(
	'typography', array(
		'title'    => esc_html__( 'Typography', 'once' ),
		'priority' => 30,
	)
);

CSCO_Kirki::add_section(
	'typography_general', array(
		'title'    => esc_html__( 'General', 'once' ),
		'panel'    => 'typography',
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'typography',
		'settings' => 'font_base',
		'label'    => esc_html__( 'Base Font', 'once' ),
		'section'  => 'typography_general',
		'default'  => array(
			'font-family'    => 'now-alt',
			'variant'        => 'regular',
			'subsets'        => array( 'latin' ),
			'font-size'      => '1rem',
			'letter-spacing' => '0',
		),
		'choices'  => apply_filters( 'powerkit_fonts_choices', array(
			'variant' => array(
				'300',
				'regular',
				'italic',
				'500',
				'700',
				'700italic',
			),
		) ),
		'priority' => 10,
		'output'   => apply_filters( 'csco_font_base', array(
			array(
				'element' => 'body',
			),
		) ),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'        => 'typography',
		'settings'    => 'font_primary',
		'label'       => esc_html__( 'Primary Font', 'once' ),
		'description' => esc_html__( 'Used for buttons, categories and tags, post meta links and other actionable elements.', 'once' ),
		'section'     => 'typography_general',
		'default'     => array(
			'font-family'    => 'now-alt',
			'variant'        => '500',
			'subsets'        => array( 'latin' ),
			'font-size'      => '0.6875rem',
			'letter-spacing' => '0.125em',
			'text-transform' => 'uppercase',
		),
		'choices'     => apply_filters( 'powerkit_fonts_choices', array(
			'variant' => array(
				'regular',
				'500',
				'700',
			),
		) ),
		'priority'    => 10,
		'output'      => apply_filters( 'csco_font_primary', array(
			array(
				'element' => 'button, .button, input[type="button"], input[type="reset"], input[type="submit"], .cs-font-primary, .no-comments, .text-action, .archive-wrap .more-link, .share-total, .nav-links, .comment-reply-link, .post-sidebar-tags a, .meta-category a, .read-more, .entry-more a, .navigation.pagination .nav-links > span, .navigation.pagination .nav-links > a, .subcategories .cs-nav-link, .cs-social-accounts .cs-social-label, .post-prev-next .link-label a, .author-social-accounts .author-social-label',
			),
			array(
				'element' => '.pk-font-primary, .entry-meta-details .pk-share-buttons-count, .entry-meta-details .pk-share-buttons-label, .post-sidebar-shares .pk-share-buttons-label, .footer-instagram .instagram-username, .pk-twitter-counters .number, .pk-instagram-counters .number, .pk-alt-instagram-counters .number, .pk-scroll-to-top .cs-btn-caption',
			),
		) ),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'        => 'typography',
		'settings'    => 'font_secondary',
		'label'       => esc_html__( 'Secondary Font', 'once' ),
		'description' => esc_html__( 'Used for post meta, image captions and other secondary elements.', 'once' ),
		'section'     => 'typography_general',
		'default'     => array(
			'font-family'    => 'now-alt',
			'subsets'        => array( 'latin' ),
			'variant'        => 'regular',
			'font-size'      => '0.6875rem',
			'letter-spacing' => '0',
			'text-transform' => 'uppercase',
		),
		'choices'     => apply_filters( 'powerkit_fonts_choices', array(
			'variant' => array(
				'regular',
				'500',
				'700',
			),
		) ),
		'priority'    => 10,
		'output'      => apply_filters( 'csco_font_secondary', array(
			array(
				'element' => 'small, input[type="text"], input[type="email"], input[type="url"], input[type="password"], input[type="search"], input[type="number"], input[type="tel"], input[type="range"], input[type="date"], input[type="month"], input[type="week"], input[type="time"], input[type="datetime"], input[type="datetime-local"], input[type="color"], div[class*="meta-"], span[class*="meta-"], select, textarea, label, .cs-font-secondary, .post-meta, .archive-count, .page-subtitle, .site-description, figcaption, .post-tags a, .tagcloud a, .post-format-icon, .comment-metadata, .says, .logged-in-as, .must-log-in, .widget_rss ul li .rss-date, .navbar-brand .tagline, .post-sidebar-shares .total-shares, .cs-breadcrumbs, .searchwp-live-search-no-results em, .searchwp-live-search-no-min-chars:after, .cs-video-tools .cs-tooltip, .entry-details .author-wrap, .entry-details .author-wrap a, .footer-copyright',
			),
			array(
				'element' => '.wp-caption-text, .wp-block-image figcaption, .wp-block-audio figcaption, .wp-block-embed figcaption, .wp-block-pullquote cite, .wp-block-pullquote.is-style-solid-color blockquote cite, .wp-block-pullquote footer, .wp-block-pullquote .wp-block-pullquote__citation, blockquote cite, .wp-block-quote cite',
			),
			array(
				'element' => '.pk-font-secondary, .pk-instagram-counters, .pk-alt-instagram-counters, .pk-twitter-counters, .pk-instagram-item .pk-instagram-data .pk-meta, .pk-alt-instagram-item .pk-alt-instagram-data .pk-meta, .entry-share .pk-share-buttons-total, .post-sidebar-shares .pk-share-buttons-total, .pk-share-buttons-after-post .pk-share-buttons-total',
			),
		) ),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'typography',
		'settings' => 'font_entry_excerpt',
		'label'    => esc_html__( 'Entry Excerpt', 'once' ),
		'section'  => 'typography_general',
		'default'  => array(
			'font-family' => 'now-alt',
			'font-size'   => '0.875rem',
			'line-height' => '1.5',
		),
		'choices'  => apply_filters( 'powerkit_fonts_choices', array(
			'variant' => array(
				'300',
				'regular',
				'italic',
				'500',
				'700',
				'700italic',
			),
		) ),
		'priority' => 10,
		'output'   => apply_filters( 'csco_font_entry_excerpt', array(
			array(
				'element' => '.entry-excerpt, .post-excerpt, .pk-alt-instagram-desc',
			),
		) ),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'typography',
		'settings' => 'font_post_content',
		'label'    => esc_html__( 'Post Content', 'once' ),
		'section'  => 'typography_general',
		'default'  => array(
			'font-family'    => 'now-alt',
			'variant'        => 'regular',
			'subsets'        => array( 'latin' ),
			'font-size'      => '0.875rem',
			'letter-spacing' => 'inherit',
		),
		'choices'  => apply_filters( 'powerkit_fonts_choices', array(
			'variant' => array(
				'300',
				'regular',
				'italic',
				'500',
				'700',
				'700italic',
			),
		) ),
		'priority' => 10,
		'output'   => apply_filters( 'csco_font_post_content', array(
			array(
				'element' => '.entry-content',
			),
		) ),
	)
);

CSCO_Kirki::add_section(
	'typography_logos', array(
		'title'    => esc_html__( 'Logos', 'once' ),
		'panel'    => 'typography',
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'        => 'typography',
		'settings'    => 'font_main_logo',
		'label'       => esc_html__( 'Main Logo', 'once' ),
		'description' => esc_html__( 'The main logo is used in the navigation bar and mobile view of your website.', 'once' ),
		'section'     => 'typography_logos',
		'default'     => array(
			'font-family'    => 'now-alt',
			'font-size'      => '1.5rem',
			'variant'        => '700',
			'subsets'        => array( 'latin' ),
			'letter-spacing' => '0.25em',
			'text-transform' => 'uppercase',
		),
		'choices'     => apply_filters( 'powerkit_fonts_choices', array() ),
		'priority'    => 10,
		'output'      => apply_filters( 'csco_font_logo', array(
			array(
				'element' => '.site-title',
			),
		) ),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'            => 'typography',
		'settings'        => 'font_large_logo',
		'label'           => esc_html__( 'Large Logo', 'once' ),
		'section'         => 'typography_logos',
		'default'         => array(
			'font-family'    => 'now-alt',
			'font-size'      => '2rem',
			'variant'        => '700',
			'subsets'        => array( 'latin' ),
			'letter-spacing' => '0.25em',
			'text-transform' => 'uppercase',
		),
		'description'     => esc_html__( 'The large logo is used in the site header in desktop view.', 'once' ),
		'choices'         => apply_filters( 'powerkit_fonts_choices', array() ),
		'priority'        => 10,
		'active_callback' => array(
			array(
				'setting'  => 'header_layout',
				'operator' => '==',
				'value'    => 'large',
			),
		),
		'output'          => apply_filters( 'csco_font_large_logo', array(
			array(
				'element' => '.large-title',
			),
		) ),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'        => 'typography',
		'settings'    => 'font_footer_logo',
		'label'       => esc_html__( 'Footer Logo', 'once' ),
		'description' => esc_html__( 'The footer logo is used in the site footer in desktop and mobile view.', 'once' ),
		'section'     => 'typography_logos',
		'default'     => array(
			'font-family'    => 'now-alt',
			'font-size'      => '1.5rem',
			'variant'        => '700',
			'subsets'        => array( 'latin' ),
			'letter-spacing' => '0.25em',
			'text-transform' => 'uppercase',
		),
		'choices'     => apply_filters( 'powerkit_fonts_choices', array() ),
		'priority'    => 10,
		'output'      => apply_filters( 'csco_font_footer_logo', array(
			array(
				'element' => '.footer-title',
			),
		) ),
	)
);

CSCO_Kirki::add_section(
	'typography_headings', array(
		'title'    => esc_html__( 'Headings', 'once' ),
		'panel'    => 'typography',
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'typography',
		'settings' => 'font_headings',
		'label'    => esc_html__( 'Headings Primary Font', 'once' ),
		'section'  => 'typography_headings',
		'default'  => array(
			'font-family'    => 'Prata',
			'variant'        => '400',
			'subsets'        => array( 'latin' ),
			'letter-spacing' => '0',
			'text-transform' => 'none',
		),
		'choices'  => apply_filters( 'powerkit_fonts_choices', array() ),
		'priority' => 10,
		'output'   => apply_filters( 'csco_font_headings', array(
			array(
				'element' => '.entry-title .title-wrap, .post-header-inner .entry-title, .comment-author .fn, blockquote, .cs-post-carousel .cs-carousel-title, .cs-subscription .cs-subscription-title, .cs-widget-author .cs-author-title, .post-author .title-author',
			),
			array(
				'element' => '.wp-block-quote, .wp-block-quote p',
			),
			array(
				'element' => '.post-subscribe .pk-title, .pk-subscribe-form-wrap .pk-font-heading, .footer-subscribe .pk-title, .pk-widget-posts-template-carousel .entry-title, .pk-alt-instagram-title .pk-alt-title, .pk-inline-posts-container .pk-title, .navbar-subscribe .pk-title:first-line',
			),
		) ),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'     => 'typography',
		'settings' => 'font_secondary_headings',
		'label'    => esc_html__( 'Headings Secondary Font', 'once' ),
		'section'  => 'typography_headings',
		'default'  => array(
			'font-family'    => 'now-alt',
			'variant'        => '500',
			'subsets'        => array( 'latin' ),
			'letter-spacing' => '-0.0125em',
			'text-transform' => 'none',
		),
		'choices'  => apply_filters( 'powerkit_fonts_choices', array() ),
		'priority' => 10,
		'output'   => apply_filters( 'csco_font_secondary_headings', array(
			array(
				'element' => 'h1, h2, h3, h4, h5, h6, .h1, .h2, .h3, .h4, .h5, .h6, .entry-title .meta-category, .entry-title .meta-category a',
			),
			array(
				'element' => '.wp-block-cover .wp-block-cover-image-text, .wp-block-cover .wp-block-cover-text, .wp-block-cover h2, .wp-block-cover-image .wp-block-cover-image-text, .wp-block-cover-image .wp-block-cover-text, .wp-block-cover-image h2, .wp-block-pullquote p, p.has-drop-cap:not(:focus):first-letter',
			),
			array(
				'element' => '.pk-font-heading, .navbar-subscribe .pk-title span',
			),
			array(
				'element' => '.entry-title-style .title-wrap:first-line, .entry-header .post-header-inner .entry-title:first-line, .archive-full .entry-title:first-line, .comment-author .fn:first-line, .cs-post-carousel .cs-carousel-title:first-line, .cs-subscription .cs-subscription-title:first-line, .post-author .title-author:first-line, .cs-widget-author .cs-author-title:first-line, .cs-mm-post .entry-title:first-line, .footer-subscribe .pk-title:first-line, .pk-subscribe-form-wrap .pk-font-heading:first-line, .pk-font-heading:first-line, .post-subscribe .pk-title:first-line, .pk-alt-instagram-title .pk-alt-title:first-line, .pk-inline-posts-container .pk-title:first-line',
			),
		) ),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'        => 'typography',
		'settings'    => 'font_title_block',
		'label'       => esc_html__( 'Section Titles', 'once' ),
		'description' => esc_html__( 'Used for widget, related posts and other sections\' titles.', 'once' ),
		'section'     => 'typography_headings',
		'default'     => array(
			'font-family'    => 'now-alt',
			'variant'        => '500',
			'subsets'        => array( 'latin' ),
			'font-size'      => '0.6875rem',
			'letter-spacing' => '0.025em',
			'text-transform' => 'uppercase',
			'color'          => '#000000',
		),
		'choices'     => apply_filters( 'powerkit_fonts_choices', array() ),
		'priority'    => 10,
		'output'      => apply_filters( 'csco_font_title_block', array(
			array(
				'element' => '.title-block, .pk-font-block',
			),
		) ),
	)
);

CSCO_Kirki::add_section(
	'typography_navigation', array(
		'title'    => esc_html__( 'Navigation', 'once' ),
		'panel'    => 'typography',
		'priority' => 10,
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'        => 'typography',
		'settings'    => 'font_menu',
		'label'       => esc_html__( 'Menu Font', 'once' ),
		'description' => esc_html__( 'Used for main top level menu elements.', 'once' ),
		'section'     => 'typography_navigation',
		'default'     => array(
			'font-family'    => 'now-alt',
			'variant'        => '500',
			'subsets'        => array( 'latin' ),
			'font-size'      => '0.875rem',
			'letter-spacing' => '0',
			'text-transform' => 'none',
		),
		'choices'     => apply_filters( 'powerkit_fonts_choices', array() ),
		'priority'    => 10,
		'output'      => apply_filters( 'csco_font_menu', array(
			array(
				'element' => '.navbar-nav > li > a, .cs-mega-menu-child > a, .widget_archive li, .widget_categories li, .widget_meta li a, .widget_nav_menu .menu > li > a, .widget_pages .page_item a',
			),
		) ),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'        => 'typography',
		'settings'    => 'font_submenu',
		'label'       => esc_html__( 'Submenu Font', 'once' ),
		'description' => esc_html__( 'Used for submenu elements.', 'once' ),
		'section'     => 'typography_navigation',
		'default'     => array(
			'font-family'    => 'now-alt',
			'subsets'        => array( 'latin' ),
			'variant'        => 'regular',
			'font-size'      => '0.8125rem',
			'letter-spacing' => '0',
			'text-transform' => 'none',
		),
		'choices'     => apply_filters( 'powerkit_fonts_choices', array() ),
		'priority'    => 10,
		'output'      => apply_filters( 'csco_font_submenu', array(
			array(
				'element' => '.navbar-nav .sub-menu > li > a, .navbar-topbar .navbar-nav > li > a, .widget_nav_menu .sub-menu > li > a',
			),
		) ),
	)
);

CSCO_Kirki::add_field(
	'csco_theme_mod', array(
		'type'        => 'typography',
		'settings'    => 'font_additional_menu',
		'label'       => esc_html__( 'Additional Menu', 'once' ),
		'description' => esc_html__( 'Used for additional menu elements.', 'once' ),
		'section'     => 'typography_navigation',
		'default'     => array(
			'font-family'    => 'now-alt',
			'variant'        => '500',
			'subsets'        => array( 'latin' ),
			'font-size'      => '0.8125rem',
			'letter-spacing' => '0',
			'text-transform' => 'none',
		),
		'choices'     => apply_filters( 'powerkit_fonts_choices', array() ),
		'priority'    => 10,
		'output'      => apply_filters( 'csco_additional_menu', array(
			array(
				'element' => '#menu-additional.navbar-nav > li > a',
			),
		) ),
	)
);
