<?php
/**
 * Template part singular content
 *
 * @package Once
 */

// Var Archive type.
$archive_layout = get_theme_mod( csco_get_archive_option( 'layout' ), 'masonry' );

// Var Summary type.
$summary_type = get_theme_mod( csco_get_archive_option( 'summary' ), 'excerpt' );
?>

<article <?php post_class(); ?>>

	<!-- Full Post Layout -->
	<?php
	if ( ! is_singular() ) {

		$class = 'entry-header-standard';

		// Check if post has an image attached.
		if ( has_post_thumbnail() ) {
			$class .= ' entry-header-thumbnail';
		}
		?>

		<div class="entry-header <?php echo esc_attr( $class ); ?>">

				<div class="entry-header-inner">

					<?php
					if ( has_post_thumbnail() ) {
						csco_post_media();
					}
					?>

					<div class="post-header-inner">

						<?php do_action( 'csco_singular_entry_header_start' ); ?>

						<?php
						if ( csco_get_post_meta( array( 'category' ), false, false, true ) ) {
							?>
							<div class="entry-inline-meta">
								<?php csco_get_post_meta( array( 'category' ), false, true, true ); ?>
							</div>
							<?php
						}
						?>

						<?php if ( get_the_title() ) { ?>
							<header class="entry-header">
								<?php csco_post_cat_and_title( 'h2', false, false ); ?>
							</header>
						<?php } ?>

						<?php
						if ( csco_get_post_meta( array( 'views', 'shares', 'comments', 'reading_time' ), false, false, true ) ) {
							?>
							<div class="entry-inline-meta">
								<?php csco_get_post_meta( array( 'views', 'shares', 'comments', 'reading_time' ), false, true, true ); ?>
							</div>
							<?php
						}
						?>

						<?php
						if ( 'excerpt' === $summary_type && get_theme_mod( csco_get_archive_option( 'excerpt' ), true ) && get_the_excerpt() ) {
							?>
							<div class="post-excerpt"><?php the_excerpt(); ?></div>
							<?php
						}

						if ( 'excerpt' === $summary_type ) {

							if ( get_theme_mod( csco_get_archive_option( 'more_button' ), false ) ) {
							?>
								<div class="entry-more">
									<a class="button" href="<?php echo esc_url( get_permalink() ); ?>">
										<?php echo esc_html( get_theme_mod( 'misc_label_readmore', __( 'Read More', 'once' ) ) ); ?>
									</a>
								</div>
							<?php
							}
						}

						// Post Details and Share.
						$post_details = csco_get_post_meta( array( 'author', 'date' ), false, false, true );

						$post_share = csco_powerkit_module_enabled( 'share_buttons' ) && powerkit_share_buttons_exists( 'post_meta' );

						if ( $post_details || $post_share ) {
						?>
							<div class="entry-bottombar">
								<?php
								if ( $post_details ) {
									csco_post_details( 'post_meta' );
								}
								?>

								<?php if ( $post_share ) { ?>
									<div class="entry-share">
										<?php powerkit_share_buttons_location( 'post_meta' ); ?>
									</div>
								<?php } ?>
							</div>
						<?php
						}
						?>

						<?php do_action( 'csco_singular_entry_header_end' ); ?>

					</div>

				</div>

			</div>
		<?php
	}
	?>

	<?php if ( is_singular() || ( ! is_singular() && ( 'full' === $archive_layout && 'content' === $summary_type ) ) ) { ?>

		<?php do_action( 'csco_singular_content_before' ); ?>

		<!-- Full Post Layout and Full Content -->
		<div class="entry entry-content-wrap">

			<?php do_action( 'csco_singular_content_start' ); ?>

			<div class="entry-content">

				<?php
				$more_link_text = false;

				if ( get_theme_mod( csco_get_archive_option( 'more_button' ), false ) ) {
					$more_link_text = sprintf(
						/* translators: %s: Name of current post */
						__( 'Continue reading<span class="screen-reader-text"> "%s"</span>', 'once' ),
						get_the_title()
					);
				}

				the_content( $more_link_text );
				?>

			</div>
			<?php do_action( 'csco_singular_content_end' ); ?>
		</div>

		<?php do_action( 'csco_singular_content_after' ); ?>

	<?php } ?>

</article>
