<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Once
 */

global $wp_query;

// Var Archive type.
if ( get_query_var( 'csco_archive_settings' ) ) {
	$settings = get_query_var( 'csco_archive_settings' );

	$post_meta             = $settings['post_meta'];
	$archive_layout        = $settings['layout'];
	$orientation           = $settings['image_orientation'];
	$group_cat_title       = $settings['group_category_title'];
	$group_author_date     = $settings['group_author_date'];
	$group_author_date_pos = $settings['group_author_date_position'];
	$excerpt               = $settings['excerpt'];
	$more_button           = $settings['more_button'];
} else {
	$post_meta = csco_get_archive_option( 'post_meta' );

	$archive_layout        = get_theme_mod( csco_get_archive_option( 'layout' ), 'masonry' );
	$orientation           = get_theme_mod( csco_get_archive_option( 'image_orientation' ), 'original' );
	$group_cat_title       = get_theme_mod( csco_get_archive_option( 'group_category_title' ), true );
	$group_author_date     = get_theme_mod( csco_get_archive_option( 'group_author_date' ), true );
	$group_author_date_pos = get_theme_mod( csco_get_archive_option( 'group_author_date_position' ), 'above' );
	$excerpt               = get_theme_mod( csco_get_archive_option( 'excerpt' ), true );
	$more_button           = get_theme_mod( csco_get_archive_option( 'more_button' ), false );
}
?>

<article <?php post_class(); ?>>
	<div class="post-outer">

		<?php
		// Post Thumbnail.
		if ( has_post_thumbnail() ) {

			// Set ratio.
			$overlay_ratio = 'cs-overlay-ratio ' . csco_get_image_ratio( $orientation );

			$image_size = 'csco-thumbnail';

			if ( 'list' === $archive_layout && 'disabled' === csco_get_page_sidebar() ) {
				$image_size = 'csco-medium';
			}

			$image_size = csco_get_image_size_by( $image_size, $orientation );
		?>
			<div class="post-inner entry-thumbnail">
				<div class="cs-overlay cs-overlay-transparent <?php echo esc_attr( $overlay_ratio ); ?>">
					<div class="<?php echo esc_attr( csco_get_overlay_type( $orientation ) ); ?>">
						<?php the_post_thumbnail( $image_size ); ?>
						<?php csco_get_video_background( 'archive', null, 'default', true, true ); ?>
					</div>
					<?php if ( get_post_format() && 'post' === get_post_type() ) { ?>
						<div class="cs-overlay-content">
							<?php csco_the_post_format_icon(); ?>
						</div>
					<?php } ?>
					<a href="<?php the_permalink(); ?>" class="cs-overlay-link"></a>
				</div>
			</div>
		<?php } ?>

		<div class="post-inner entry-data">

			<?php
			if ( $group_author_date && 'above' === $group_author_date_pos ) {
				csco_post_details( $post_meta );
			} elseif ( ! $group_cat_title ) {
				csco_get_post_meta( 'category', false, true, $post_meta );
			}
			?>

			<?php if ( get_the_title() ) { ?>
				<header class="entry-header">
					<?php csco_post_cat_and_title( 'h2', $post_meta, $group_cat_title ); ?>
				</header>
			<?php } ?>

			<?php
			$post_meta_kit = csco_get_post_meta_kit( $post_meta, $group_cat_title, $group_author_date, $group_author_date_pos );

			csco_get_post_meta( $post_meta_kit, false, true, $post_meta );
			?>

			<?php if ( $excerpt && get_the_excerpt() ) { ?>
				<div class="entry-excerpt">
					<?php echo wp_kses( get_the_excerpt(), 'post' ); ?>
				</div>
			<?php } ?>

			<?php
			if ( $group_author_date && 'below' === $group_author_date_pos ) {
				csco_post_details( $post_meta );
			}
			?>

			<?php if ( $more_button ) { ?>
				<div class="entry-more">
					<a class="button" href="<?php echo esc_url( get_permalink() ); ?>">
						<?php echo esc_html( get_theme_mod( 'misc_label_readmore', __( 'Read More', 'once' ) ) ); ?>
					</a>
				</div>
			<?php } ?>

			<?php if ( csco_powerkit_module_enabled( 'share_buttons' ) && powerkit_share_buttons_exists( 'post_meta' ) ) { ?>
				<div class="entry-share">
					<?php powerkit_share_buttons_location( 'post_meta' ); ?>
				</div>
			<?php } ?>

		</div>

	</div><!-- .post-outer -->
</article>
