<?php
/**
 * Template part for displaying featured section.
 *
 * @package Once
 */

$ids = csco_get_featured_ids();

if ( $ids ) {
	$args = array(
		'ignore_sticky_posts' => true,
		'post__in'            => $ids,
		'posts_per_page'      => count( $ids ),
		'post_type'           => array( 'post', 'page' ),
		'orderby'             => 'post__in',
	);

	$the_query = new WP_Query( $args );
}

// Determines whether there are more posts available in the loop.
if ( $ids && $the_query->have_posts() ) {
	do_action( 'csco_featured_post_before' );

	while ( $the_query->have_posts() ) {

		$the_query->the_post();

		$layout = get_theme_mod( 'featured_layout', 'small' );

		if ( 'default' === $layout ) {
			$layout = csco_get_page_header_type( get_the_ID() );
		}

		// Set type of post.
		if ( 'small' === $layout ) {
			$type = 'small';
		} elseif ( 'boxed' === $layout ) {
			$type = 'boxed';
		} elseif ( 'large' === $layout ) {
			$type = 'large';
		} else {
			$type = 'standard';
		}

		// Set ratio.
		$ratio = null;

		if ( 'standard' === $type || 'large' === $type ) {
			$ratio = 'cs-overlay-ratio cs-ratio-wide';
		}

		// Set image size.
		if ( 'small' === $type ) {
			$image_size = 'csco-large-uncropped';
		} elseif ( 'boxed' === $type ) {
			$image_size = 'csco-large-uncropped';
		} elseif ( 'large' === $type ) {
			$image_size = 'csco-extra-large';
		} else {
			$image_size = 'csco-large';
		}

		// Group category and post title.
		$group_cat_title = get_theme_mod( 'featured_group_category_title', false );

		// Get background color.
		$background = get_theme_mod( 'featured_background', '#FFFFFF' );

		// Set section class.
		$scheme = ( 'boxed' === $type ) ? false : 'auto';

		$class = csco_section_class( 'section-featured-post', $background, $scheme );

		if ( has_post_thumbnail() ) {
			$class .= ' section-featured-' . $type;
		}
		?>

		<div class="<?php echo esc_attr( $class ); ?>">

			<?php do_action( 'csco_featured_post_start' ); ?>

			<div class="cs-container">

				<div class="cs-featured-post cs-featured-post-<?php echo esc_attr( $type ); ?>">

					<?php if ( has_post_thumbnail() ) { ?>
						<div class="featured-post-media cs-video-wrap">
							<div class="cs-overlay cs-overlay-transparent <?php echo esc_attr( $ratio ); ?>">
								<div class="<?php echo esc_attr( $ratio ? 'cs-overlay-background' : 'cs-background' ); ?>">
									<?php
									the_post_thumbnail( $image_size, array(
										'class' => 'pk-lazyload-disabled',
									) );
									?>
									<?php csco_get_video_background( 'featured', null, 'large', true, true ); ?>

									<span class="cs-overlay-blank"></span>
								</div>

								<?php if ( get_post_format() && 'post' === get_post_type() && ( 'standard' === $type || 'large' === $type ) ) { ?>
									<div class="cs-overlay-content">
										<?php csco_the_post_format_icon(); ?>
									</div>
								<?php } ?>

								<a href="<?php the_permalink(); ?>" class="cs-overlay-link"></a>
							</div>
						</div>
					<?php } ?>

					<?php
					$post_scheme = null;
					if ( 'boxed' === $type ) {
						$post_scheme = csco_light_or_dark( get_theme_mod( 'color_accent', '#FAFAFA' ), null, ' cs-bg-dark' );
					}
					?>

					<div class="featured-post-inner <?php echo esc_attr( $post_scheme ); ?>">

						<?php
						if ( ! $group_cat_title && csco_get_post_meta( array( 'category' ), false, false, 'featured_meta' ) ) {
							?>
							<div class="entry-inline-meta">
								<?php csco_get_post_meta( array( 'category' ), false, true, 'featured_meta' ); ?>
							</div>
							<?php
						}
						?>

						<?php if ( get_the_title() ) { ?>
							<header class="entry-header">
								<?php csco_post_cat_and_title( 'h2', 'featured_meta', $group_cat_title ); ?>
							</header>
						<?php } ?>

						<?php
						$post_meta_kit = array( 'views', 'shares', 'comments', 'reading_time' );

						if ( ! csco_has_post_meta( 'author', 'featured_meta' ) || ! csco_has_post_meta( 'date', 'featured_meta' ) ) {
							array_unshift( $post_meta_kit, 'author', 'date' );
						}

						if ( csco_get_post_meta( $post_meta_kit, false, false, 'featured_meta' ) ) {
							?>
							<div class="entry-inline-meta">
								<?php csco_get_post_meta( $post_meta_kit, false, true, 'featured_meta' ); ?>
							</div>
							<?php
						}
						?>

						<?php
						if ( get_theme_mod( 'featured_excerpt', true ) && get_the_excerpt() ) {
							?>
							<div class="entry-excerpt"><?php the_excerpt(); ?></div>
							<?php
						}
						?>

						<?php csco_post_details( 'featured_meta', true, 'featured_meta' ); ?>

					</div>

				</div>

			</div>

			<?php do_action( 'csco_featured_post_end' ); ?>

		</div>
	<?php
	}

	wp_reset_postdata();

	do_action( 'csco_featured_post_after' );
}
