<?php
/**
 * Template part for displaying subscription section.
 *
 * @package Once
 */

if ( shortcode_exists( 'powerkit_subscription_form' ) ) {

	do_action( 'csco_subscription_before' );

	// Get background color.
	$background = get_theme_mod( 'subscription_background', '#FAFAFA' );

	// Set section class.
	$class = csco_section_class( 'section-subscription', $background );
	?>

	<div class="<?php echo esc_attr( $class ); ?>">

		<?php do_action( 'csco_subscription_start' ); ?>

			<div class="cs-container">

				<div class="cs-subscription">
					<?php
						$title = get_theme_mod( 'subscription_title', esc_html__( 'Subscribe to Get Our', 'once' ) . "\n" . esc_html__( 'Newsletter', 'once' ) );
						$name  = get_theme_mod( 'subscription_name', true );
						?>
							<h3 class="cs-subscription-title">
								<?php echo wp_kses( nl2br( $title ), 'post' ); ?>
							</h3>
						<?php
						echo do_shortcode( sprintf( '[powerkit_subscription_form display_name="%s"]', $name ) );
					?>
				</div>

			</div>

		<?php do_action( 'csco_subscription_end' ); ?>

	</div>

	<?php
	do_action( 'csco_subscription_after' );
}
