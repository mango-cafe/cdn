<?php
/**
 * Template part for displaying tiles section.
 *
 * @package Once
 */

$ids = csco_get_tiles_ids();

if ( $ids ) {
	$args = array(
		'ignore_sticky_posts' => true,
		'post__in'            => $ids,
		'posts_per_page'      => count( $ids ),
		'post_type'           => array( 'post', 'page' ),
		'orderby'             => 'post__in',
	);

	$the_query = new WP_Query( $args );
}

// Determines whether there are more posts available in the loop.
if ( $ids && $the_query->have_posts() ) {
	do_action( 'csco_post_tiles_before' );

	$type = get_theme_mod( 'tiles_type', 'type-1' );

	// Get background color.
	$background = get_theme_mod( 'tiles_background', '#FFFFFF' );

	// Set section class.
	$class = csco_section_class( 'section-post-tiles', $background );
?>

	<div class="<?php echo esc_attr( $class ); ?>">

		<?php do_action( 'csco_post_tiles_start' ); ?>

			<div class="cs-container">

				<div class="cs-post-tiles cs-post-tiles-<?php echo esc_attr( $type ); ?>">
					<?php
					set_query_var( 'csco_tile_query', $the_query );
					set_query_var( 'csco_tile_thumb_attr', array(
						'class' => 'pk-lazyload-disabled',
					) );

					if ( 'type-1' === $type ) {
						?>
							<div class="cs-post-tiles-column">
								<?php
									csco_get_posts_tiles( array(
										'tile-full',
									) );
								?>
							</div>
							<div class="cs-post-tiles-column">
								<?php
									csco_get_posts_tiles( array(
										'tile-grid',
										'tile-grid',
										'tile-grid',
										'tile-grid',
									) );
								?>
							</div>
						<?php
					} elseif ( 'type-2' === $type ) {
						?>
							<div class="cs-post-tiles-column">
								<?php
									csco_get_posts_tiles( array(
										'tile-full',
									) );
								?>
							</div>
							<div class="cs-post-tiles-column">
								<?php
									csco_get_posts_tiles( array(
										'tile-grid',
										'tile-grid',
									) );
								?>
							</div>
							<div class="cs-post-tiles-column">
								<?php
									csco_get_posts_tiles( array(
										'tile-grid',
										'tile-grid',
									) );
								?>
							</div>
						<?php
					} elseif ( 'type-3' === $type ) {
						?>
							<div class="cs-post-tiles-column">
								<?php
									csco_get_posts_tiles( array(
										'tile-full',
									) );
								?>
							</div>
							<div class="cs-post-tiles-column">
								<?php
									csco_get_posts_tiles( array(
										'tile-grid',
										'tile-grid',
									) );
								?>
							</div>
						<?php
					} elseif ( 'type-4' === $type || 'type-5' === $type ) {
						?>
							<div class="cs-post-tiles-column">
								<?php
									csco_get_posts_tiles( array(
										'tile-full',
									) );
								?>
							</div>
							<div class="cs-post-tiles-column">
								<?php
									csco_get_posts_tiles( array(
										'tile-list',
										'tile-list',
										'tile-list',
										'tile-list',
										'tile-list',
									) );
								?>
							</div>
						<?php
					}
					?>
				</div>

				<?php wp_reset_postdata(); ?>
			</div>

		<?php do_action( 'csco_post_tiles_end' ); ?>

	</div>

	<?php
	do_action( 'csco_post_tiles_after' );
}
