<?php
/**
 * The template part for displaying post prev next section.
 *
 * @package Once
 */

global $post;

$prev_post = get_previous_post();
$next_post = get_next_post();

$type = get_theme_mod( 'post_prev_next', 'along' );

$class = sprintf( 'post-prev-next-%s', $type );

$class .= ( $prev_post && $next_post ) ? ' post-prev-next-grid' : ' post-prev-next-list';

if ( $prev_post || $next_post ) {

	// Get image orientation.
	$orientation = get_theme_mod( 'post_prev_next_image_orientation', 'landscape' );

	// Set ratio.
	$ratio = csco_get_image_ratio( $orientation );

	// Thumbnail size item.
	$image_size = 'csco-thumbnail';

	if ( 'below' === $type && 'disabled' === csco_get_page_sidebar() ) {
		$image_size = 'csco-medium';
	}

	$image_size = csco_get_image_size_by( $image_size, $orientation );

	$group_cat_title = get_theme_mod( 'post_prev_next_group_category_title', true );

	if ( 'along' === $type ) {
		$class .= csco_light_or_dark( get_theme_mod( 'color_accent', '#FAFAFA' ), null, ' cs-bg-dark' );
	}
	?>
	<div class="post-prev-next <?php echo esc_attr( $class ); ?>">
		<?php
		// Prev post.
		if ( $prev_post ) {
			$post = $prev_post;

			setup_postdata( $post );
			?>
				<div class="link-content prev-link">
					<div class="link-label">
						<a class="link-arrow" href="<?php the_permalink(); ?>">
							<?php esc_html_e( 'Previous Article', 'once' ); ?>
						</a>
					</div>

					<article <?php post_class(); ?>>
						<div class="post-outer">
							<?php
							// Post Thumbnail.
							if ( has_post_thumbnail() ) {
								?>
								<div class="post-inner entry-thumbnail">
									<div class="cs-overlay cs-overlay-transparent cs-overlay-ratio <?php echo esc_attr( $ratio ); ?>">
										<div class="<?php echo esc_attr( csco_get_overlay_type( $orientation ) ); ?>">
											<?php the_post_thumbnail( $image_size ); ?>
											<?php csco_get_video_background( 'archive' ); ?>
										</div>
										<?php if ( get_post_format() && 'post' === get_post_type() ) { ?>
											<div class="cs-overlay-content">
												<?php csco_the_post_format_icon(); ?>
											</div>
										<?php } ?>
										<a href="<?php the_permalink(); ?>" class="cs-overlay-link"></a>
									</div>
								</div>
							<?php } ?>

							<div class="post-inner">

								<?php csco_post_details( 'post_prev_next_post_meta', true, 'post_prev_next_post_meta' ); ?>

								<?php if ( get_the_title() ) { ?>
									<header class="entry-header">
										<?php csco_post_cat_and_title( 'h2', 'post_prev_next_post_meta', $group_cat_title ); ?>
									</header>
								<?php } ?>

								<?php
								$post_meta_kit = csco_get_post_meta_kit( 'post_prev_next_post_meta', $group_cat_title, true );

								csco_get_post_meta( $post_meta_kit, false, true, 'post_prev_next_post_meta' );
								?>
							</div>

						</div>

					</article>
				</div>
			<?php
			wp_reset_postdata();
		}

		// Next post.
		if ( $next_post ) {
			$post = $next_post;

			setup_postdata( $post );
			?>
				<div class="link-content next-link">
					<div class="link-label">
						<a class="link-arrow" href="<?php the_permalink(); ?>">
							<?php esc_html_e( 'Next Article', 'once' ); ?>
						</a>
					</div>

					<article <?php post_class(); ?>>
						<div class="post-outer">
							<?php
							// Post Thumbnail.
							if ( has_post_thumbnail() ) {
								?>
								<div class="post-inner entry-thumbnail">
									<div class="cs-overlay cs-overlay-transparent cs-overlay-ratio <?php echo esc_attr( $ratio ); ?>">
										<div class="<?php echo esc_attr( csco_get_overlay_type( $orientation ) ); ?>">
											<?php the_post_thumbnail( $image_size ); ?>
											<?php csco_get_video_background( 'archive' ); ?>
										</div>
										<?php if ( get_post_format() && 'post' === get_post_type() ) { ?>
											<div class="cs-overlay-content">
												<?php csco_the_post_format_icon(); ?>
											</div>
										<?php } ?>
										<a href="<?php the_permalink(); ?>" class="cs-overlay-link"></a>
									</div>
								</div>
							<?php } ?>

							<div class="post-inner">

								<?php csco_post_details( 'post_prev_next_post_meta', true, 'post_prev_next_post_meta' ); ?>

								<?php if ( get_the_title() ) { ?>
									<header class="entry-header">
										<?php csco_post_cat_and_title( 'h2', 'post_prev_next_post_meta', $group_cat_title ); ?>
									</header>
								<?php } ?>

								<?php
								$post_meta_kit = csco_get_post_meta_kit( 'post_prev_next_post_meta', $group_cat_title, true );

								csco_get_post_meta( $post_meta_kit, false, true, 'post_prev_next_post_meta' );
								?>
							</div>

						</div>

					</article>
				</div>
			<?php
			wp_reset_postdata();
		}
		?>
	</div>
	<?php
}
