<?php
/**
 * The template part for displaying post subscribe section.
 *
 * @package Once
 */

// Subscription.
$subscription_form = get_theme_mod( 'post_subscribe', false );

if ( shortcode_exists( 'powerkit_subscription_form' ) && $subscription_form ) {
	$title = get_theme_mod( 'post_subscribe_title', esc_html__( 'Subscribe to Get Our', 'once' ) . "\n" . esc_html__( 'Newsletter', 'once' ) );
	$text  = get_theme_mod( 'post_subscribe_text', esc_html__( 'Get notified of the best deals on our WordPress themes.', 'once' ) );
	$name  = get_theme_mod( 'post_subscribe_name', false );

	$scheme = csco_light_or_dark( get_theme_mod( 'color_accent', '#FAFAFA' ), null, 'cs-bg-dark' );

	do_action( 'csco_post_subscribe_before' );
	?>
	<div class="post-subscribe <?php echo esc_attr( $scheme ); ?>">

		<div class="subscribe-wrap">
			<?php echo do_shortcode( sprintf( '[powerkit_subscription_form display_name="%s" title="%s" text="%s"]', $name, nl2br( $title ), nl2br( $text ) ) ); ?>
		</div>

	</div>

	<?php
	do_action( 'csco_post_subscribe_after' );
}
