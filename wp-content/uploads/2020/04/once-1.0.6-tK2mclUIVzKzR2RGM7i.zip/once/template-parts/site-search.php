<?php
/**
 * The template part for displaying site section.
 *
 * @package Once
 */

$scheme = csco_light_or_dark( get_theme_mod( 'color_accent', '#FAFAFA' ), null, 'cs-bg-dark' );
?>

<div class="site-search-wrap <?php echo esc_attr( $scheme ); ?>" id="search">
	<div class="site-search">
		<div class="cs-container">
			<div class="search-form-wrap">
				<?php get_search_form( true ); ?>
				<span class="search-close"></span>
			</div>
		</div>
	</div>
</div>
